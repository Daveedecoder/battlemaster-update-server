@extends('layouts.user')

@section('title', $challenge->title)

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- Back Button -->
    <a href="{{ route('challenges.user.index') }}" class="inline-flex items-center text-blue-600 hover:text-blue-800 dark:text-blue-400 mb-6">
        <i class="fas fa-arrow-left mr-2"></i> Back to Challenges
    </a>

    <!-- Challenge Header -->
    <div class="bg-gradient-to-br from-blue-700/90 via-purple-800/90 to-blue-900/90 rounded-2xl p-8 text-white shadow-elevated mb-8 card-enhanced relative overflow-hidden">
        <div class="absolute inset-0 pointer-events-none" style="background: radial-gradient(circle at 80% 20%, rgba(255,255,255,0.08) 0, transparent 70%);"></div>
        <div class="flex justify-between items-start">
            <div>
                <div class="mb-2">
                    <h1 class="text-4xl font-extrabold drop-shadow-lg px-2 py-1 bg-white/80 dark:bg-gray-900/80 text-gray-900 dark:text-white rounded-lg inline-block">{{ $challenge->title }}</h1>
                </div>
                <div class="flex items-center space-x-4 mt-2">
                    <span class="px-3 py-1 bg-white/30 dark:bg-gray-900/40 backdrop-blur text-white rounded-lg font-mono text-sm border border-white/30 shadow">
                        {{ $challenge->challenge_number ?? 'CH-' . str_pad($challenge->id, 8, '0', STR_PAD_LEFT) }}
                    </span>
                    <p class="text-blue-100 text-lg font-mono tracking-wide">{{ $challenge->game }}</p>
                </div>
            </div>
            <span class="px-4 py-2 text-sm font-semibold rounded-full {{ $challenge->status_badge }} shadow">
                {{ ucfirst($challenge->status) }}
            </span>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <div class="glassmorphism rounded-xl p-4 border border-white/20 dark:border-gray-700">
                <p class="text-blue-100 text-xs font-semibold mb-1 uppercase tracking-wider">Prize Pool</p>
                <p class="text-3xl font-extrabold">{{ format_user_currency($challenge->prize_amount, null, optional($challenge->creator->currency)->code) }}</p>
            </div>
            <div class="glassmorphism rounded-xl p-4 border border-white/20 dark:border-gray-700">
                <p class="text-blue-100 text-xs font-semibold mb-1 uppercase tracking-wider">Format</p>
                <p class="text-3xl font-extrabold">{{ strtoupper($challenge->format) }}</p>
            </div>
            <div class="glassmorphism rounded-xl p-4 border border-white/20 dark:border-gray-700">
                <p class="text-blue-100 text-xs font-semibold mb-1 uppercase tracking-wider">Participants</p>
                <p class="text-3xl font-extrabold">{{ $challenge->current_participants }}/{{ $challenge->required_participants }}</p>
            </div>
        </div>
    </div>

    <!-- Challenge Details -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div class="lg:col-span-2">
            <!-- Description & Rules -->
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
                @if($challenge->description)
                    <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4">Description</h2>
                    <p class="text-gray-700 dark:text-gray-300 mb-6 break-words">{{ $challenge->description }}</p>
                @endif

                @if($challenge->rules)
                    <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4">Rules</h2>
                    <div class="text-gray-700 dark:text-gray-300 whitespace-pre-line break-words overflow-wrap-anywhere max-w-full">{{ $challenge->rules }}</div>
                @endif
            </div>

            <!-- Teams -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Team A -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                    <h3 class="text-lg font-bold text-gray-900 dark:text-white mb-4">
                        <i class="fas fa-users text-blue-500 mr-2"></i>Team A
                    </h3>
                    <div class="space-y-3">
                        @forelse($challenge->teamAParticipants as $participant)
                            <div class="flex items-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                                <div class="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold mr-3">
                                    {{ substr($participant->user->name, 0, 1) }}
                                </div>
                                <div class="flex-1">
                                    <p class="font-semibold text-gray-900 dark:text-white">{{ $participant->user->name }}</p>
                                    @if($participant->status === 'winner')
                                        <span class="text-xs text-green-600 dark:text-green-400 font-semibold">
                                            <i class="fas fa-trophy mr-1"></i>Winner
                                        </span>
                                    @endif
                                </div>
                            </div>
                        @empty
                            <p class="text-gray-500 dark:text-gray-400 text-center py-4 text-sm">No participants yet</p>
                        @endforelse
                        
                        @for($i = $challenge->teamAParticipants->count(); $i < $challenge->team_size; $i++)
                            <div class="flex items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg opacity-50">
                                <div class="w-10 h-10 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center text-gray-500 font-bold mr-3">
                                    <i class="fas fa-user"></i>
                                </div>
                                <p class="text-gray-500 dark:text-gray-400 text-sm">Waiting for player...</p>
                            </div>
                        @endfor
                    </div>
                </div>

                <!-- Team B -->
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                    <h3 class="text-lg font-bold text-gray-900 dark:text-white mb-4">
                        <i class="fas fa-users text-red-500 mr-2"></i>Team B
                    </h3>
                    <div class="space-y-3">
                        @forelse($challenge->teamBParticipants as $participant)
                            <div class="flex items-center p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                                <div class="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center text-white font-bold mr-3">
                                    {{ substr($participant->user->name, 0, 1) }}
                                </div>
                                <div class="flex-1">
                                    <p class="font-semibold text-gray-900 dark:text-white">{{ $participant->user->name }}</p>
                                    @if($participant->status === 'winner')
                                        <span class="text-xs text-green-600 dark:text-green-400 font-semibold">
                                            <i class="fas fa-trophy mr-1"></i>Winner
                                        </span>
                                    @endif
                                </div>
                            </div>
                        @empty
                            <p class="text-gray-500 dark:text-gray-400 text-center py-4 text-sm">No participants yet</p>
                        @endforelse
                        
                        @for($i = $challenge->teamBParticipants->count(); $i < $challenge->team_size; $i++)
                            <div class="flex items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg opacity-50">
                                <div class="w-10 h-10 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center text-gray-500 font-bold mr-3">
                                    <i class="fas fa-user"></i>
                                </div>
                                <p class="text-gray-500 dark:text-gray-400 text-sm">Waiting for player...</p>
                            </div>
                        @endfor
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar Actions -->
        <div class="lg:col-span-1">
            <div class="bg-white/80 dark:bg-gray-800/90 glassmorphism rounded-2xl shadow-elevated p-6 sticky top-4 border border-gray-200 dark:border-gray-700">
                <h3 class="text-lg font-extrabold text-gray-900 dark:text-white mb-4 tracking-wide">Actions</h3>
                
                @if($userParticipation)
                    <!-- User is participating -->
                    <div class="mb-4 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                        <p class="text-green-800 dark:text-green-300 text-sm font-semibold">
                            <i class="fas fa-check-circle mr-1"></i>You're in {{ $userParticipation->team_display }}!
                        </p>
                    </div>

                    @if($challenge->status === 'open')
                        <form action="{{ route('challenges.user.leave', $challenge) }}" method="POST">
                            @csrf
                            <button type="submit" class="w-full bg-red-600 hover:bg-red-700 text-white py-3 rounded-lg transition mb-3" onclick="return confirm('Are you sure you want to leave? You will be refunded.')">
                                <i class="fas fa-sign-out-alt mr-2"></i>Leave Challenge
                            </button>
                        </form>
                    @endif

                    @if($challenge->status === 'full' && $challenge->creator_id === auth()->id())
                        <form action="{{ route('challenges.user.start', $challenge) }}" method="POST">
                            @csrf
                            <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg transition mb-3">
                                <i class="fas fa-play mr-2"></i>Start Challenge
                            </button>
                        </form>
                    @endif

                    {{-- Opponent Verification Status --}}
                    @if($challenge->status === 'pending_opponent_verification')
                        @if($needsVerification)
                            {{-- Show Accept/Dispute buttons for user who needs to verify --}}
                            <div class="mb-3 p-4 bg-blue-50 dark:bg-blue-900/20 border-l-4 border-blue-500 rounded">
                                <div class="flex items-start">
                                    <i class="fas fa-user-check text-blue-600 dark:text-blue-400 mt-1 mr-3"></i>
                                    <div class="flex-1">
                                        <p class="font-semibold text-blue-800 dark:text-blue-300 mb-1">Verification Required</p>
                                        <p class="text-sm text-blue-700 dark:text-blue-400 mb-3">
                                            The other team has claimed victory. Please review the proof and confirm the result.
                                        </p>
                                        <div class="flex gap-2">
                                            <button onclick="document.getElementById('acceptModal').classList.remove('hidden')" class="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg transition text-sm font-semibold">
                                                <i class="fas fa-check mr-1"></i>Accept Winner
                                            </button>
                                            <button onclick="document.getElementById('disputeModal').classList.remove('hidden')" class="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-lg transition text-sm font-semibold">
                                                <i class="fas fa-times mr-1"></i>Dispute
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @else
                            {{-- Show waiting message when user already submitted proof --}}
                            <div class="mb-3 p-4 bg-orange-50 dark:bg-orange-900/20 border-l-4 border-orange-500 rounded">
                                <div class="flex items-start">
                                    <i class="fas fa-clock text-orange-600 dark:text-orange-400 mt-1 mr-3"></i>
                                    <div>
                                        <p class="font-semibold text-orange-800 dark:text-orange-300 mb-1">Waiting for Verification</p>
                                        <p class="text-sm text-orange-700 dark:text-orange-400">
                                            Your proof has been submitted. Waiting for the other team to accept or dispute the result.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        @endif
                    @endif

                    {{-- Dispute Support Ticket Banner --}}
                    @if($challenge->status === 'disputed')
                        @php
                            $escrow = $challenge->escrows()->first();
                        @endphp
                        @if($escrow && $escrow->support_ticket_id && $escrow->supportTicket)
                            <div class="mb-3 p-4 bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500 rounded">
                                <div class="flex items-start">
                                    <i class="fas fa-gavel text-red-600 dark:text-red-400 mt-1 mr-3 text-xl"></i>
                                    <div class="flex-1">
                                        <h4 class="font-bold text-red-800 dark:text-red-300 mb-2 text-lg">⚠️ Challenge Under Dispute Review</h4>
                                        <p class="text-sm text-red-700 dark:text-red-400 mb-3">
                                            This challenge result is being disputed. Both teams can submit evidence and communicate with the escrow team through the support ticket below.
                                        </p>
                                        <div class="bg-red-100 dark:bg-red-900/40 rounded-lg p-3 mb-3">
                                            <p class="text-xs text-red-800 dark:text-red-300 font-semibold mb-2">
                                                <i class="fas fa-info-circle mr-1"></i>Both Teams Have Equal Access
                                            </p>
                                            <p class="text-xs text-red-700 dark:text-red-400">
                                                Both teams can view and reply to this ticket. Upload screenshots, videos, or any evidence to support your claim. The escrow team will review all submissions and determine the rightful winner.
                                            </p>
                                        </div>
                                        <a href="{{ route('user.support.show', $escrow->supportTicket) }}" 
                                           class="inline-flex items-center bg-red-600 hover:bg-red-700 text-white px-4 py-2.5 rounded-lg transition font-semibold shadow-md hover:shadow-lg">
                                            <i class="fas fa-ticket-alt mr-2"></i>
                                            View Dispute Ticket #{{ $escrow->supportTicket->ticket_number }}
                                            <i class="fas fa-arrow-right ml-2"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endif
                    @endif

                    @if(in_array($challenge->status, ['finished', 'ongoing']) && $userParticipation->isActive())
                        @if($proofSubmitted)
                            <!-- Warning: Proof already submitted -->
                            <div class="mb-3 p-4 bg-yellow-50 dark:bg-yellow-900/20 border-l-4 border-yellow-500 rounded">
                                <div class="flex items-start">
                                    <i class="fas fa-exclamation-triangle text-yellow-600 dark:text-yellow-400 mt-1 mr-3"></i>
                                    <div>
                                        <p class="font-semibold text-yellow-800 dark:text-yellow-300 mb-1">Proof Already Submitted</p>
                                        <p class="text-sm text-yellow-700 dark:text-yellow-400 mb-2">
                                            Another participant has already submitted proof for this challenge. If you believe you won and disagree with the submitted proof, please contact support immediately.
                                        </p>
                                        <a href="{{ route('user.support.create') }}" class="inline-flex items-center text-sm font-semibold text-yellow-800 dark:text-yellow-300 hover:text-yellow-900 dark:hover:text-yellow-200">
                                            <i class="fas fa-headset mr-2"></i>Contact Support
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endif
                        <button onclick="document.getElementById('proofModal').classList.remove('hidden')" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg transition">
                            <i class="fas fa-file-upload mr-2"></i>Submit Proof
                        </button>
                    @endif
                @else
                    <!-- User not participating -->
                    @if(in_array($challenge->status, ['open', 'full']) && $canJoin['can_join'])
                        <form action="{{ route('challenges.user.join', $challenge) }}" method="POST">
                            @csrf
                            <button type="submit" class="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3 rounded-lg transition shadow-lg transform hover:scale-105 mb-3">
                                <i class="fas fa-sign-in-alt mr-2"></i>Join Challenge
                            </button>
                        </form>
                        <p class="text-sm text-gray-600 dark:text-gray-400">
                            Entry fee: {{ format_currency_simple($canJoin['entry_amount'], auth()->user()->currency) }}
                        </p>
                    @elseif(!$canJoin['can_join'])
                        <div class="p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                            @foreach($canJoin['errors'] as $error)
                                <p class="text-red-800 dark:text-red-300 text-sm mb-1">
                                    <i class="fas fa-exclamation-circle mr-1"></i>{{ $error }}
                                </p>
                            @endforeach
                        </div>
                    @endif
                @endif

                <!-- Challenge Info -->
                <div class="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <div class="space-y-3 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-500 dark:text-gray-400">Creator</span>
                            <span class="font-semibold text-gray-900 dark:text-white">{{ $challenge->creator->name }}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-500 dark:text-gray-400">Created</span>
                            <span class="font-semibold text-gray-900 dark:text-white">{{ $challenge->created_at->diffForHumans() }}</span>
                        </div>
                        @if($challenge->started_at)
                            <div class="flex justify-between">
                                <span class="text-gray-500 dark:text-gray-400">Started</span>
                                <span class="font-semibold text-gray-900 dark:text-white">{{ $challenge->started_at->diffForHumans() }}</span>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Submit Proof Modal -->
<div id="proofModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-md w-full mx-4">
        <h3 class="text-xl font-bold text-gray-900 dark:text-white mb-4">Submit Proof</h3>
        <form action="{{ route('challenges.user.submit-proof', $challenge) }}" method="POST" enctype="multipart/form-data">
            @csrf
            <!-- No winner selection needed; just upload proof -->
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Proof File (Screenshot/Video)</label>
                <input type="file" name="proof_file" accept="image/*,video/*,application/pdf" required class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white">
                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Max 50MB. Accepted: JPG, PNG, PDF, MP4, AVI, MOV</p>
            </div>
            <div class="flex justify-end gap-3">
                <button type="button" onclick="document.getElementById('proofModal').classList.add('hidden')" class="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition">
                    Cancel
                </button>
                <button type="submit" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition">
                    Submit Proof
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Accept Verification Modal -->
<div id="acceptModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-md w-full mx-4">
        <h3 class="text-xl font-bold text-gray-900 dark:text-white mb-4">Accept Result</h3>
        <form action="{{ route('challenges.user.accept-verification', $challenge) }}" method="POST">
            @csrf
            <div class="mb-4">
                <p class="text-gray-700 dark:text-gray-300 mb-3">
                    Are you sure you want to accept this result? The challenge will proceed to admin verification for prize release.
                </p>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Note (Optional)</label>
                <textarea name="note" rows="3" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white" placeholder="Add any comments..."></textarea>
            </div>
            <div class="flex justify-end gap-3">
                <button type="button" onclick="document.getElementById('acceptModal').classList.add('hidden')" class="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition">
                    Cancel
                </button>
                <button type="submit" class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition">
                    <i class="fas fa-check mr-1"></i>Accept Result
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Dispute Verification Modal -->
<div id="disputeModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-md w-full mx-4">
        <h3 class="text-xl font-bold text-gray-900 dark:text-white mb-4">Dispute Result</h3>
        <form action="{{ route('challenges.user.dispute-verification', $challenge) }}" method="POST">
            @csrf
            <div class="mb-4">
                <div class="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-4">
                    <div class="flex items-start">
                        <i class="fas fa-ticket-alt text-blue-600 dark:text-blue-400 mt-0.5 mr-3 text-lg"></i>
                        <div class="flex-1">
                            <p class="font-semibold text-blue-900 dark:text-blue-100 mb-2">
                                📋 Dispute Will Be Created as Support Ticket
                            </p>
                            <p class="text-sm text-blue-800 dark:text-blue-200 mb-2">
                                Your dispute will automatically create a support ticket where:
                            </p>
                            <ul class="text-sm text-blue-700 dark:text-blue-300 space-y-1 ml-4">
                                <li>• <strong>Both teams</strong> can view and reply</li>
                                <li>• You can upload evidence (screenshots, videos, etc.)</li>
                                <li>• The escrow team will review all submissions</li>
                                <li>• You'll be notified of the final decision</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <p class="text-gray-700 dark:text-gray-300 mb-3">
                    Explain why you believe the result is incorrect. Be specific and prepare to provide evidence.
                </p>
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Reason for Dispute <span class="text-red-500">*</span></label>
                <textarea name="reason" rows="4" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white" placeholder="Explain why you're disputing this result..." required></textarea>
            </div>
            <div class="flex justify-end gap-3">
                <button type="button" onclick="document.getElementById('disputeModal').classList.add('hidden')" class="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition">
                    Cancel
                </button>
                <button type="submit" class="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition">
                    <i class="fas fa-times mr-1"></i>Submit Dispute
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
