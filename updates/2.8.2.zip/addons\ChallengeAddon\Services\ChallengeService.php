<?php

namespace ChallengeAddon\Services;

use ChallengeAddon\Models\Challenge;
use ChallengeAddon\Models\ChallengeParticipant;
use ChallengeAddon\Models\ChallengeEscrow;
use App\Models\User;
use App\Models\Wallet;
use App\Models\WalletTransaction;
use App\Models\SupportTicket;
use App\Models\Currency;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Mail;
use App\Notifications\GeneralNotification;
use App\Http\Controllers\Admin\CurrencyController;

class ChallengeService
{
    /**
     * Get system base currency (exchange_rate = 1.0) with USD fallback
     */
    private function getBaseCurrency(): ?Currency
    {
        return Currency::where('exchange_rate', 1.0000)->first()
            ?? Currency::where('code', 'USD')->first();
    }

    /**
     * Convert amount from a given currency to the system base currency using API/fallback
     */
    private function convertToBase(float $amount, ?Currency $fromCurrency): float
    {
        $base = $this->getBaseCurrency();
        if (!$fromCurrency || !$base || $fromCurrency->id === $base->id) {
            return round($amount, 2);
        }

        return CurrencyController::convertCurrency($amount, $fromCurrency, $base);
    }

    /**
     * Calculate prize pool in base currency using live rates (API with DB fallback)
     */
    private function calculatePrizePoolInBase(Challenge $challenge): float
    {
        $participants = $challenge->participants()->with('user.currency')->get();
        $total = 0;

        foreach ($participants as $participant) {
            $from = $participant->user ? $participant->user->currency : null;
            $total += $this->convertToBase((float) $participant->bet_amount, $from);
        }

        return round($total, 2);
    }
    /**
     * Calculate escrow fee
     */
    public function calculateEscrowFee(float $amount, float $feePercentage = 5.0): float
    {
        return $amount * ($feePercentage / 100);
    }

    /**
     * Process challenge completion
     */
    public function completeChallenge(Challenge $challenge, string $winnerTeam): bool
    {
        return DB::transaction(function () use ($challenge, $winnerTeam) {
            // Update challenge status
            $challenge->update([
                'status' => 'finished',
                'ended_at' => now()
            ]);

            // Calculate prize pool (total amount from all participants) in base currency
            $prizePool = $this->calculatePrizePoolInBase($challenge);

            // Create escrow record
            $escrow = ChallengeEscrow::create([
                'challenge_id' => $challenge->id,
                'winner_team' => $winnerTeam,
                'total_amount' => $prizePool,
                'final_amount' => $prizePool,
                'status' => 'pending'
            ]);

            // Update winner participants status
            ChallengeParticipant::where('challenge_id', $challenge->id)
                ->where('team', $winnerTeam)
                ->update(['status' => 'winner']);

            // Update loser participants status
            $loserTeam = $winnerTeam === 'team_a' ? 'team_b' : 'team_a';
            ChallengeParticipant::where('challenge_id', $challenge->id)
                ->where('team', $loserTeam)
                ->update(['status' => 'loser']);

            Log::info("ChallengeAddon: Challenge finished, awaiting proof submission", [
                'challenge_id' => $challenge->id,
                'winner_team' => $winnerTeam
            ]);

            return true;
        });
    }

    /**
     * Process escrow release
     */
    public function releaseEscrow(ChallengeEscrow $escrow, string $adminNotes = null): bool
    {
        return DB::transaction(function () use ($escrow, $adminNotes) {
            // Get fee percentage from settings
            $feePercentage = \App\Models\Setting::get('challenge_escrow_fee', 5);

            // Calculate final amount after fees
            $feeAmount = $this->calculateEscrowFee($escrow->total_amount, $feePercentage);
            $finalAmount = $escrow->total_amount - $feeAmount;

            // Update escrow record
            $escrow->update([
                'status' => 'completed',
                'fee_amount' => $feeAmount,
                'final_amount' => $finalAmount,
                'admin_notes' => $adminNotes ?: 'Funds released automatically.',
                'released_at' => now()
            ]);

            // Get winning team participants
            $winners = $escrow->winningParticipants();

            // Calculate amount per winner
            $amountPerWinner = $finalAmount / $winners->count();

            // Credit each winner's wallet
            foreach ($winners as $winner) {
                $wallet = Wallet::firstOrCreate(['user_id' => $winner->user_id]);
                $wallet->increment('balance', $amountPerWinner);

                // Create transaction record
                WalletTransaction::create([
                    'user_id' => $winner->user_id,
                    'type' => 'credit',
                    'amount' => $amountPerWinner,
                    'description' => "Challenge prize - {$escrow->challenge->title}",
                    'reference' => "challenge_prize_{$escrow->challenge->id}",
                    'status' => 'completed'
                ]);

                Log::info("ChallengeAddon: Credited winner", [
                    'user_id' => $winner->user_id,
                    'amount' => $amountPerWinner,
                    'challenge_id' => $escrow->challenge->id
                ]);

                // Send email to winner
                try {
                    if ($winner->user && $winner->user->email) {
                        Mail::to($winner->user->email)
                            ->send(new \ChallengeAddon\Mail\EscrowReleasedMail(
                                $escrow,
                                $amountPerWinner,
                                $winner->user
                            ));
                    }
                } catch (\Exception $e) {
                    Log::warning('Failed to send escrow released email', ['error' => $e->getMessage()]);
                }
            }

            // Update challenge status
            $escrow->challenge->update([
                'status' => 'completed'
            ]);

            // Send completion email to all participants
            try {
                $allParticipants = $escrow->challenge->participants()->with('user')->get();
                foreach ($allParticipants as $participant) {
                    if ($participant->user && $participant->user->email) {
                        Mail::to($participant->user->email)
                            ->send(new \ChallengeAddon\Mail\ChallengeCompletedMail(
                                $escrow->challenge,
                                $participant->user,
                                $escrow->winner_team
                            ));
                    }
                }
            } catch (\Exception $e) {
                Log::warning("Failed to send challenge completed emails", ['error' => $e->getMessage()]);
            }

            return true;
        });
    }

    /**
     * Process escrow refund (for cancelled challenges)
     * NOTE: Refunds return the FULL bet_amount to participants - NO FEES are deducted
     */
    public function refundEscrow(Challenge $challenge, string $reason = 'Challenge cancelled'): bool
    {
        return DB::transaction(function () use ($challenge, $reason) {
            // Get all participants who paid (exclude only declined participants)
            $participants = $challenge->participants()
                ->whereNotIn('status', ['declined'])
                ->get();

            Log::info("ChallengeAddon: Starting refund process (no fees deducted)", [
                'challenge_id' => $challenge->id,
                'total_participants' => $participants->count(),
                'reason' => $reason
            ]);

            $refundedCount = 0;
            $totalRefunded = 0;

            foreach ($participants as $participant) {
                // Credit wallet with FULL bet amount (no fees on refunds)
                $wallet = Wallet::firstOrCreate(['user_id' => $participant->user_id]);
                $wallet->increment('balance', $participant->bet_amount);

                // Create transaction record
                WalletTransaction::create([
                    'user_id' => $participant->user_id,
                    'type' => 'credit',
                    'amount' => $participant->bet_amount,
                    'description' => "Challenge refund - {$challenge->title}: {$reason}",
                    'reference' => "challenge_refund_{$challenge->id}_{$participant->user_id}_" . time(),
                    'status' => 'completed'
                ]);

                $refundedCount++;
                $totalRefunded += $participant->bet_amount;

                Log::info("ChallengeAddon: Refunded participant", [
                    'user_id' => $participant->user_id,
                    'amount' => $participant->bet_amount,
                    'challenge_id' => $challenge->id,
                    'participant_status' => $participant->status
                ]);
            }

            // Update challenge status
            $challenge->update(['status' => 'cancelled']);

            Log::info("ChallengeAddon: Refund process completed", [
                'challenge_id' => $challenge->id,
                'refunded_count' => $refundedCount,
                'total_amount' => $totalRefunded
            ]);

            return true;
        });
    }

    /**
     * Get challenge statistics
     */
    public function getChallengeStats(): array
    {
        return [
            'total_challenges' => Challenge::count(),
            'active_challenges' => Challenge::whereIn('status', ['open', 'full', 'ongoing'])->count(),
            'completed_challenges' => Challenge::where('status', 'completed')->count(),
            'total_participants' => ChallengeParticipant::count(),
            'total_prize_pool' => Challenge::with('creator.currency')->get()->sum(function ($challenge) {
                return $this->convertToBase((float) $challenge->prize_amount, optional($challenge->creator)->currency);
            }),
            'pending_escrows' => ChallengeEscrow::where('status', 'awaiting_verification')->count(),
            'disputed_escrows' => ChallengeEscrow::where('status', 'disputed')->count(),
            'total_fees_collected' => ChallengeEscrow::where('status', 'completed')->sum('fee_amount')
        ];
    }

    /**
     * Check if user can join challenge
     */
    public function canUserJoinChallenge(Challenge $challenge, User $user): array
    {
        $errors = [];

        if (!in_array($challenge->status, ['open', 'full'])) {
            $errors[] = 'Challenge is not open for registration.';
        }

        if ($challenge->isUserParticipating($user)) {
            $errors[] = 'You are already participating in this challenge.';
        }

        if ($challenge->isFull()) {
            $errors[] = 'Challenge is full.';
        }

        // Convert prize amount from creator's currency to user's currency first
        $challenge->load('creator.currency');
        $user->load('currency');

        $prizeAmountInUserCurrency = $challenge->prize_amount;

        if ($challenge->creator && $challenge->creator->currency && $user->currency) {
            $prizeAmountInUserCurrency = \App\Http\Controllers\Admin\CurrencyController::convertCurrency(
                $challenge->prize_amount,
                $challenge->creator->currency,
                $user->currency
            );
        }

        // Calculate the entry amount from the converted prize amount
        $entryAmount = $prizeAmountInUserCurrency / $challenge->team_size;

        $wallet = Wallet::where('user_id', $user->id)->first();
        if (!$wallet || $wallet->balance < $entryAmount) {
            $errors[] = "Insufficient wallet balance. Required: " . format_user_currency($entryAmount, $user);
        }

        return [
            'can_join' => empty($errors),
            'errors' => $errors,
            'entry_amount' => $entryAmount ?? 0
        ];
    }

    /**
     * Process challenge participation
     */
    public function joinChallenge(Challenge $challenge, User $user): bool
    {
        $validation = $this->canUserJoinChallenge($challenge, $user);

        if (!$validation['can_join']) {
            throw new \Exception(implode(' ', $validation['errors']));
        }

        return DB::transaction(function () use ($challenge, $user, $validation) {
            $entryAmount = $validation['entry_amount'];

            // Deduct entry amount
            $wallet = Wallet::firstOrCreate(['user_id' => $user->id]);
            $wallet->decrement('balance', $entryAmount);

            // Create wallet transaction
            WalletTransaction::create([
                'user_id' => $user->id,
                'type' => 'debit',
                'amount' => $entryAmount,
                'description' => "Challenge entry - {$challenge->title}",
                'reference' => "challenge_entry_{$challenge->id}",
                'status' => 'completed'
            ]);

            // Determine which team to join
            $team = $challenge->getAvailableTeam();

            if (!$team) {
                throw new \Exception('No available team slot.');
            }

            // Add participant
            ChallengeParticipant::create([
                'challenge_id' => $challenge->id,
                'user_id' => $user->id,
                'team' => $team,
                'bet_amount' => $entryAmount,
                'status' => 'accepted',
                'joined_at' => now(),
                'responded_at' => now()
            ]);

            // Update participant count
            $challenge->increment('current_participants');

            // Check if challenge is now full
            if ($challenge->current_participants >= $challenge->required_participants) {
                $challenge->update(['status' => 'full']);
            }

            Log::info("ChallengeAddon: User joined challenge", [
                'user_id' => $user->id,
                'challenge_id' => $challenge->id,
                'team' => $team,
                'amount' => $entryAmount
            ]);

            // Send notification to the user who joined
            $user->notify(new \App\Notifications\GeneralNotification(
                'Challenge Joined Successfully',
                "You have successfully joined '{$challenge->title}'. Your team assignment is " . ($team === 'team_a' ? 'Team A' : 'Team B') . ". Waiting for the creator to start the challenge.",
                route('challenges.user.show', $challenge),
                'success'
            ));

            // Send email to challenge creator
            try {
                Mail::to($challenge->creator->email)
                    ->send(new \ChallengeAddon\Mail\ChallengeJoinedMail($challenge, $user));
            } catch (\Exception $e) {
                Log::warning("Failed to send challenge joined email", ['error' => $e->getMessage()]);
            }

            return true;
        });
    }

    /**
     * Start a challenge
     */
    public function startChallenge(Challenge $challenge): bool
    {
        if ($challenge->status !== 'full') {
            throw new \Exception('Challenge must be full before starting.');
        }

        return DB::transaction(function () use ($challenge) {
            $challenge->update([
                'status' => 'ongoing',
                'started_at' => now()
            ]);

            // Update all participants to active
            ChallengeParticipant::where('challenge_id', $challenge->id)
                ->whereIn('status', ['pending', 'accepted'])
                ->update(['status' => 'active']);

            Log::info("ChallengeAddon: Challenge started", [
                'challenge_id' => $challenge->id
            ]);

            return true;
        });
    }

    /**
     * Submit proof for challenge
     * Note: Users no longer choose a winner. Proof submission only records the submitter and file,
     * and moves the challenge into opponent verification without setting a winner.
     */
    public function submitProof(Challenge $challenge, string $proofPath, User $submitter): bool
    {
        if (!in_array($challenge->status, ['ongoing', 'finished'])) {
            throw new \Exception('Challenge must be ongoing or finished to submit proof.');
        }

        return DB::transaction(function () use ($challenge, $proofPath, $submitter) {
            // Update challenge to finished if not already
            if ($challenge->status !== 'finished') {
                $challenge->update([
                    'status' => 'finished',
                    'ended_at' => now()
                ]);
            }

            // Get or create escrow
            $escrow = $challenge->escrows()->first();
            if (!$escrow) {
                $prizePool = $this->calculatePrizePoolInBase($challenge);
                $escrow = ChallengeEscrow::create([
                    'challenge_id' => $challenge->id,
                    // Do not set winner_team on proof submission; this will be decided after verification/admin
                    'total_amount' => $prizePool,
                    'final_amount' => $prizePool,
                    'status' => 'pending'
                ]);
            }

            // Determine which team submitted proof (submitter's team)
            $submitterParticipation = $challenge->participants()
                ->where('user_id', $submitter->id)
                ->first();
            $submitterTeam = $submitterParticipation ? $submitterParticipation->team : null;

            // Always require opponent verification regardless of who submits
            $escrow->update([
                'proof_file_path' => $proofPath,
                'proof_submitted_by' => $submitter->id,
                'proof_submitter_team' => $submitterTeam,
                'opponent_verification_status' => 'pending',
                'team_a_verification_status' => 'pending',
                'team_b_verification_status' => 'pending',
                'status' => 'pending_opponent_verification',
                // winner_team not set here
            ]);

            $challenge->update(['status' => 'pending_opponent_verification']);

            // Notify the opponent team to verify
            $opponentTeam = $submitterTeam === 'team_a' ? 'team_b' : 'team_a';
            $opponentParticipants = $challenge->participants()
                ->where('team', $opponentTeam)
                ->with('user')
                ->get();

            foreach ($opponentParticipants as $participant) {
                if ($participant->user) {
                    $participant->user->notify(new GeneralNotification(
                        'Challenge Result Verification Required',
                        "The other team has claimed victory in '{$challenge->title}'. Please review and verify the result.",
                        route('challenges.user.show', $challenge),
                        'info'
                    ));
                }
            }

            Log::info("ChallengeAddon: Proof submitted - awaiting opponent verification", [
                'challenge_id' => $challenge->id,
                'submitter_team' => $submitterTeam
            ]);

            return true;
        });
    }

    /**
     * Accept opponent verification
     */
    public function acceptOpponentVerification(Challenge $challenge, User $user, ?string $note = null): bool
    {
        return DB::transaction(function () use ($challenge, $user, $note) {
            $escrow = $challenge->escrows()->first();

            if (!$escrow || $escrow->opponent_verification_status !== 'pending') {
                throw new \Exception('No pending verification found.');
            }

            // Determine which team the user is on
            $userParticipation = $challenge->participants()->where('user_id', $user->id)->first();
            if (!$userParticipation) {
                throw new \Exception('You are not a participant in this challenge.');
            }

            $userTeam = $userParticipation->team;

            // Opponent accepted - send directly to admin
            $escrow->update([
                'opponent_verification_status' => 'accepted',
                $userTeam . '_verification_status' => 'accepted',
                $userTeam . '_verified_by' => $user->id,
                $userTeam . '_verified_at' => now(),
                'status' => 'awaiting_verification'
            ]);

            $challenge->update(['status' => 'awaiting_verification']);

            // Notify all participants that it's awaiting admin review
            $allParticipants = $challenge->participants()->with('user')->get();
            foreach ($allParticipants as $participant) {
                if ($participant->user) {
                    $participant->user->notify(new GeneralNotification(
                        'Challenge Verified - Awaiting Admin Review',
                        "Result verified for '{$challenge->title}'. Awaiting admin review for prize release.",
                        route('challenges.user.show', $challenge),
                        'success'
                    ));
                }
            }

            Log::info("ChallengeAddon: Opponent accepted result, sent to admin", [
                'challenge_id' => $challenge->id,
                'user_id' => $user->id
            ]);

            return true;
        });
    }

    /**
     * Dispute opponent verification
     */
    public function disputeOpponentVerification(Challenge $challenge, User $user, string $reason): SupportTicket
    {
        return DB::transaction(function () use ($challenge, $user, $reason) {
            $escrow = $challenge->escrows()->first();

            if (!$escrow || $escrow->opponent_verification_status !== 'pending') {
                throw new \Exception('No pending verification found.');
            }

            // Determine teams based on who submitted the proof since no winner is chosen at submission
            $winningTeam = $escrow->proof_submitter_team; // claimed by submitter's team
            $losingTeam = $winningTeam === 'team_a' ? 'team_b' : 'team_a';

            $losingTeamParticipants = $challenge->participants()->where('team', $losingTeam)->with('user')->get();
            $winningTeamParticipants = $challenge->participants()->where('team', $winningTeam)->with('user')->get();

            // Create support ticket for the dispute with detailed info
            $ticket = SupportTicket::create([
                'user_id' => $user->id,
                'subject' => "Challenge Dispute - {$challenge->title}",
                'message' => "**⚠️ CHALLENGE DISPUTE - BOTH TEAMS CAN REPLY HERE ⚠️**\n\n" .
                    "**Challenge Details:**\n" .
                    "• Title: {$challenge->title}\n" .
                    "• Challenge #: {$challenge->challenge_number}\n" .
                    "• Game: {$challenge->game}\n" .
                    "• Format: " . strtoupper($challenge->format) . "\n" .
                    "• Prize Amount: " . format_user_currency($challenge->prize_amount, $user) . "\n\n" .
                    "**Dispute Information:**\n" .
                    "• Disputed By: {$user->name} ({$user->username}) - " . ($losingTeam === 'team_a' ? 'Team A' : 'Team B') . "\n" .
                    "• Claimed Winner: " . ($winningTeam === 'team_a' ? 'Team A' : 'Team B') . "\n" .
                    "• Disputed At: " . now()->format('M d, Y h:i A') . "\n\n" .
                    "**Dispute Reason:**\n{$reason}\n\n" .
                    "---\n\n" .
                    "**📌 IMPORTANT NOTICE TO BOTH TEAMS:**\n" .
                    "Both teams can reply to this ticket to provide evidence, screenshots, or explanations.\n" .
                    "Please upload any proof that supports your claim.\n" .
                    "The escrow team will review all submissions and determine the rightful winner.\n\n" .
                    "**Winning Team Members:**\n" .
                    $winningTeamParticipants->map(fn($p) => "• {$p->user->name} ({$p->user->username})")->join("\n") . "\n\n" .
                    "**Disputing Team Members:**\n" .
                    $losingTeamParticipants->map(fn($p) => "• {$p->user->name} ({$p->user->username})")->join("\n"),
                'priority' => 'high',
                'status' => 'open',
                'category' => 'dispute'
            ]);

            // Update escrow with dispute info AND link to support ticket
            $escrow->update([
                'opponent_verification_status' => 'disputed',
                'status' => 'disputed',
                'dispute_reason' => $reason,
                'disputed_at' => now(),
                'disputed_by' => $user->id,
                'support_ticket_id' => $ticket->id
            ]);

            $challenge->update(['status' => 'disputed']);

            // Notify ALL participants from BOTH teams about the dispute and give them ticket access
            $allParticipants = $challenge->participants()->with('user')->get();

            foreach ($allParticipants as $participant) {
                if ($participant->user) {
                    $isWinningTeam = $participant->team === $winningTeam;

                    $participant->user->notify(new GeneralNotification(
                        'Challenge Dispute - Action Required',
                        $isWinningTeam
                            ? "Your victory in '{$challenge->title}' has been disputed! Please provide evidence in support ticket #{$ticket->ticket_number} to support your claim."
                            : "A dispute has been raised for '{$challenge->title}'. Support ticket #{$ticket->ticket_number} has been created. Both teams can submit evidence.",
                        route('user.support.show', $ticket),
                        'warning'
                    ));
                }
            }

            Log::info("ChallengeAddon: Challenge disputed - Support ticket created for both teams", [
                'challenge_id' => $challenge->id,
                'disputed_by_user_id' => $user->id,
                'ticket_id' => $ticket->id,
                'ticket_number' => $ticket->ticket_number,
                'winning_team' => $winningTeam,
                'disputing_team' => $losingTeam
            ]);

            return $ticket;
        });
    }
}
