<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('support_tickets', function (Blueprint $table) {
            $table->string('attachment_path')->nullable()->after('message');
        });

        Schema::table('support_ticket_replies', function (Blueprint $table) {
            $table->string('attachment_path')->nullable()->after('message');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('support_tickets', function (Blueprint $table) {
            $table->dropColumn('attachment_path');
        });

        Schema::table('support_ticket_replies', function (Blueprint $table) {
            $table->dropColumn('attachment_path');
        });
    }
};
