<?php

namespace ChallengeAddon\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ChallengeAddon\Models\Challenge;
use ChallengeAddon\Models\ChallengeParticipant;
use ChallengeAddon\Models\ChallengeEscrow;
use ChallengeAddon\Services\ChallengeService;
use App\Models\WalletTransaction;
use App\Models\Wallet;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;

class ChallengeUserController extends Controller
{
    protected $challengeService;

    public function __construct(ChallengeService $challengeService)
    {
        $this->challengeService = $challengeService;
    }

    /**
     * Display a listing of challenges
     */
    public function index(Request $request)
    {
        $user = auth()->user();
        $tab = $request->get('tab', 'open'); // open, my-challenges, completed

        // Open challenges (available to join)
        if ($tab === 'open') {
            $query = Challenge::with(['creator.currency', 'participants'])
                ->whereIn('status', ['open', 'full'])
                ->orderBy('created_at', 'desc');

            // Filter by game if provided
            if ($request->filled('game')) {
                $query->where('game', $request->game);
            }

            // Filter by format
            if ($request->filled('format')) {
                $query->where('format', $request->format);
            }

            // Filter by prize range
            if ($request->filled('min_prize')) {
                $query->where('prize_amount', '>=', $request->min_prize);
            }
            if ($request->filled('max_prize')) {
                $query->where('prize_amount', '<=', $request->max_prize);
            }

            $challenges = $query->paginate(12)->appends(['tab' => 'open']);
        }
        // Challenges user is involved in (created or joined)
        elseif ($tab === 'my-challenges') {
            $challenges = Challenge::where(function ($query) use ($user) {
                $query->whereHas('participants', function ($q) use ($user) {
                    $q->where('user_id', $user->id);
                })->orWhere('creator_id', $user->id);
            })
                ->with(['creator.currency', 'participants.user', 'teamAParticipants', 'teamBParticipants'])
                ->orderBy('created_at', 'desc')
                ->paginate(12)->appends(['tab' => 'my-challenges']);
        }
        // Completed challenges
        elseif ($tab === 'completed') {
            $challenges = Challenge::whereIn('status', ['finished', 'awaiting_verification', 'completed'])
                ->where(function ($query) use ($user) {
                    $query->whereHas('participants', function ($q) use ($user) {
                        $q->where('user_id', $user->id);
                    })->orWhere('creator_id', $user->id);
                })
                ->with(['creator.currency', 'participants.user'])
                ->orderBy('ended_at', 'desc')
                ->paginate(12)->appends(['tab' => 'completed']);
        } else {
            $challenges = collect();
        }

        // Get unique games and formats for filters
        $games = Challenge::distinct('game')->pluck('game');
        $formats = ['1v1', '2v2', '3v3', '4v4', '5v5'];

        return view('challenge-addon::user.challenges.index', compact('challenges', 'games', 'formats', 'tab'));
    }

    /**
     * Display my challenges page
     */
    public function myChallenges()
    {
        return $this->index(request()->merge(['tab' => 'my-challenges']));
    }

    /**
     * Show the form for creating a new challenge
     */
    public function create()
    {
        $formats = ['1v1', '2v2', '3v3', '4v4', '5v5'];
        return view('challenge-addon::user.challenges.create', compact('formats'));
    }

    /**
     * Store a newly created challenge
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'game' => 'required|string|max:100',
            'format' => 'required|in:1v1,2v2,3v3,4v4,5v5',
            'prize_amount' => 'required|numeric|min:1',
            'rules' => 'nullable|string'
        ]);

        $user = auth()->user();

        // Require creator to have the full prize pool to create the challenge
        $teamSize = (int) substr($validated['format'], 0, 1);
        // Always treat prize pool as NGN (no conversion)
        $prizePool = $validated['prize_amount'];
        $wallet = Wallet::firstOrCreate(['user_id' => $user->id]);

        // Fetch all wallet records for this user for debugging
        $allWallets = Wallet::where('user_id', $user->id)->get();
        \Log::info('Challenge creation: wallet balance check', [
            'user_id' => $user->id,
            'wallet_id' => $wallet->id,
            'wallet_balance' => $wallet->balance,
            'prize_pool' => $prizePool,
            'currency_id' => $user->currency_id,
            'all_wallets' => $allWallets->map(function ($w) {
                return [
                    'id' => $w->id,
                    'balance' => $w->balance,
                    'locked_balance' => $w->locked_balance,
                    'created_at' => $w->created_at,
                    'updated_at' => $w->updated_at
                ];
            })
        ]);
        if ($wallet->balance < $prizePool) {
            return redirect()->back()
                ->withInput()
                ->with('error', "Insufficient wallet balance. You need ₦" . number_format($prizePool, 2) . " to create this challenge.");
        }

        try {
            DB::transaction(function () use ($validated, $user, $prizePool, &$challenge, $teamSize) {
                $validated['creator_id'] = $user->id;
                $validated['status'] = 'open';

                // Create challenge
                $challenge = Challenge::create($validated);

                // Deduct full prize pool from creator's wallet
                $wallet = Wallet::firstOrCreate(['user_id' => $user->id]);
                $wallet->decrement('balance', $prizePool);

                // Create wallet transaction with user's currency
                WalletTransaction::create([
                    'user_id' => $user->id,
                    'type' => 'debit',
                    'amount' => $prizePool,
                    'currency' => $user->currency_code,
                    'description' => "Challenge creation - {$challenge->title}",
                    'reference' => "challenge_create_{$challenge->id}",
                    'status' => 'completed'
                ]);

                // Add creator as first participant in Team A
                ChallengeParticipant::create([
                    'challenge_id' => $challenge->id,
                    'user_id' => $user->id,
                    'team' => 'team_a',
                    'bet_amount' => $prizePool,
                    'status' => 'accepted',
                    'joined_at' => now(),
                    'responded_at' => now()
                ]);

                // Update participant count
                $challenge->increment('current_participants');

                Log::info("ChallengeAddon: Challenge created", [
                    'challenge_id' => $challenge->id,
                    'user_id' => $user->id,
                    'format' => $challenge->format
                ]);
            });

            // Send email to creator
            try {
                \Mail::to($user->email)
                    ->send(new \ChallengeAddon\Mail\ChallengeCreatedMail($challenge));
            } catch (\Exception $e) {
                Log::warning("Failed to send challenge created email", ['error' => $e->getMessage()]);
            }

            return redirect()->route('challenges.user.show', $challenge)
                ->with('success', 'Challenge created successfully! Waiting for participants to join.');
        } catch (\Exception $e) {
            Log::error("ChallengeAddon: Failed to create challenge", [
                'error' => $e->getMessage(),
                'user_id' => $user->id
            ]);

            return redirect()->back()
                ->withInput()
                ->with('error', 'Failed to create challenge: ' . $e->getMessage());
        }
    }

    /**
     * Display the specified challenge
     */
    public function show(Challenge $challenge)
    {
        $challenge->load([
            'creator.currency',
            'participants.user',
            'teamAParticipants.user',
            'teamBParticipants.user',
            'escrows'
        ]);

        $user = auth()->user();
        $userParticipation = $challenge->participants()->where('user_id', $user->id)->first();
        $canJoin = $this->challengeService->canUserJoinChallenge($challenge, $user);

        // Check if proof has been submitted
        $proofSubmitted = $challenge->escrows()->whereNotNull('proof_file_path')->exists();

        // Get escrow for verification status
        $escrow = $challenge->escrows()->first();

        // Check if user needs to verify (only if opponent marked themselves as winner)
        $needsVerification = false;

        if ($escrow && $userParticipation && $escrow->opponent_verification_status === 'pending') {
            // User needs to verify if they are on opposite team from who submitted proof
            // and the submitter marked themselves as winner
            $needsVerification = $userParticipation->team !== $escrow->proof_submitter_team;
        }

        return view('challenge-addon::user.challenges.show', compact('challenge', 'userParticipation', 'canJoin', 'proofSubmitted', 'escrow', 'needsVerification'));
    }

    /**
     * Join a challenge
     */
    public function join(Challenge $challenge)
    {
        $user = auth()->user();

        try {
            $this->challengeService->joinChallenge($challenge, $user);

            return redirect()->route('challenges.user.show', $challenge)
                ->with('success', 'Successfully joined the challenge!');
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to join challenge: ' . $e->getMessage());
        }
    }

    /**
     * Leave a challenge (only before it starts)
     */
    public function leave(Challenge $challenge)
    {
        $user = auth()->user();
        $participant = $challenge->participants()->where('user_id', $user->id)->first();

        if (!$participant) {
            return redirect()->back()
                ->with('error', 'You are not participating in this challenge.');
        }

        if ($challenge->status !== 'open') {
            return redirect()->back()
                ->with('error', 'Cannot leave challenge after it has started or been filled.');
        }

        try {
            DB::transaction(function () use ($challenge, $participant, $user) {
                // Refund the participant
                $wallet = Wallet::firstOrCreate(['user_id' => $user->id]);
                $wallet->increment('balance', $participant->bet_amount);

                // Create transaction record
                WalletTransaction::create([
                    'user_id' => $user->id,
                    'type' => 'credit',
                    'amount' => $participant->bet_amount,
                    'description' => "Challenge refund - {$challenge->title}",
                    'reference' => "challenge_leave_{$challenge->id}",
                    'status' => 'completed'
                ]);

                // Remove participant
                $participant->delete();

                // Update participant count
                $challenge->decrement('current_participants');

                // If challenge was full, set it back to open
                if ($challenge->status === 'full') {
                    $challenge->update(['status' => 'open']);
                }

                Log::info("ChallengeAddon: User left challenge", [
                    'user_id' => $user->id,
                    'challenge_id' => $challenge->id
                ]);
            });

            return redirect()->route('challenges.user.index')
                ->with('success', 'Successfully left the challenge and received refund.');
        } catch (\Exception $e) {
            Log::error("ChallengeAddon: Failed to leave challenge", [
                'error' => $e->getMessage(),
                'user_id' => $user->id,
                'challenge_id' => $challenge->id
            ]);

            return redirect()->back()
                ->with('error', 'Failed to leave challenge: ' . $e->getMessage());
        }
    }

    /**
     * Start a challenge (when full)
     */
    public function start(Challenge $challenge)
    {
        $user = auth()->user();

        if ($challenge->creator_id !== $user->id) {
            return redirect()->back()
                ->with('error', 'Only the challenge creator can start the challenge.');
        }

        try {
            $this->challengeService->startChallenge($challenge);

            return redirect()->route('challenges.user.show', $challenge)
                ->with('success', 'Challenge started! Good luck to all participants.');
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to start challenge: ' . $e->getMessage());
        }
    }

    /**
     * Submit proof of results
     */
    public function submitProof(Request $request, Challenge $challenge)
    {
        $user = auth()->user();

        // Only creator or participants can submit proof
        if ($challenge->creator_id !== $user->id && !$challenge->isUserParticipating($user)) {
            return redirect()->back()
                ->with('error', 'Only challenge participants can submit proof.');
        }

        $validated = $request->validate([
            'winner_team' => 'required|in:team_a,team_b',
            'proof_file' => 'required|file|mimes:jpg,jpeg,png,pdf,mp4,avi,mov|max:51200' // 50MB max
        ]);

        try {
            // Store the proof file
            $proofPath = $request->file('proof_file')->store('challenge_proofs', 'public');

            // Submit proof
            $this->challengeService->submitProof($challenge, $proofPath, $validated['winner_team'], $user);

            return redirect()->route('challenges.user.show', $challenge)
                ->with('success', 'Proof submitted successfully! Awaiting opponent verification.');
        } catch (\Exception $e) {
            Log::error("ChallengeAddon: Failed to submit proof", [
                'error' => $e->getMessage(),
                'user_id' => $user->id,
                'challenge_id' => $challenge->id
            ]);

            return redirect()->back()
                ->with('error', 'Failed to submit proof: ' . $e->getMessage());
        }
    }

    /**
     * Finish a challenge (mark as complete)
     */
    public function finish(Request $request, Challenge $challenge)
    {
        $user = auth()->user();

        if ($challenge->creator_id !== $user->id) {
            return redirect()->back()
                ->with('error', 'Only the challenge creator can finish the challenge.');
        }

        $validated = $request->validate([
            'winner_team' => 'required|in:team_a,team_b'
        ]);

        try {
            $this->challengeService->completeChallenge($challenge, $validated['winner_team']);

            return redirect()->route('challenges.user.show', $challenge)
                ->with('success', 'Challenge marked as finished! Please submit proof for verification.');
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to finish challenge: ' . $e->getMessage());
        }
    }

    /**
     * Show the form for editing the specified challenge
     */
    public function edit(Challenge $challenge)
    {
        $user = auth()->user();

        if ($challenge->creator_id !== $user->id) {
            abort(403, 'Unauthorized action.');
        }

        if ($challenge->status !== 'open') {
            return redirect()->back()
                ->with('error', 'Cannot edit challenge after it has been filled or started.');
        }

        $formats = ['1v1', '2v2', '3v3', '4v4', '5v5'];
        return view('challenge-addon::user.challenges.edit', compact('challenge', 'formats'));
    }

    /**
     * Update the specified challenge
     */
    public function update(Request $request, Challenge $challenge)
    {
        $user = auth()->user();

        if ($challenge->creator_id !== $user->id) {
            abort(403, 'Unauthorized action.');
        }

        if ($challenge->status !== 'open') {
            return redirect()->back()
                ->with('error', 'Cannot edit challenge after it has been filled or started.');
        }

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'game' => 'required|string|max:100',
            'rules' => 'nullable|string'
        ]);

        $challenge->update($validated);

        return redirect()->route('challenges.user.show', $challenge)
            ->with('success', 'Challenge updated successfully!');
    }

    /**
     * Cancel a challenge
     */
    public function destroy(Challenge $challenge)
    {
        $user = auth()->user();

        if ($challenge->creator_id !== $user->id) {
            abort(403, 'Unauthorized action.');
        }

        if (!in_array($challenge->status, ['open', 'full'])) {
            return redirect()->back()
                ->with('error', 'Cannot cancel challenge at this stage.');
        }

        try {
            $this->challengeService->refundEscrow($challenge, 'Challenge cancelled by creator');

            return redirect()->route('challenges.user.index')
                ->with('success', 'Challenge cancelled and all participants refunded.');
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to cancel challenge: ' . $e->getMessage());
        }
    }

    /**
     * Accept opponent verification
     */
    public function acceptVerification(Request $request, Challenge $challenge)
    {
        $user = auth()->user();

        // Check if user is a participant
        if (!$challenge->isUserParticipating($user)) {
            return redirect()->back()
                ->with('error', 'Only challenge participants can verify results.');
        }

        // Check if there's a pending verification
        $escrow = $challenge->escrows()->first();
        if (!$escrow || $escrow->opponent_verification_status !== 'pending') {
            return redirect()->back()
                ->with('error', 'No pending verification found.');
        }

        // Check if user is from the losing team (opponent of winner)
        $participant = $challenge->participants()->where('user_id', $user->id)->first();
        if ($participant->team === $escrow->winner_team) {
            return redirect()->back()
                ->with('error', 'You cannot verify your own win.');
        }

        try {
            $validated = $request->validate([
                'note' => 'nullable|string|max:500'
            ]);

            $this->challengeService->acceptOpponentVerification($challenge, $user, $validated['note'] ?? null);

            return redirect()->route('challenges.user.show', $challenge)
                ->with('success', 'You have accepted the result. The challenge is now awaiting admin verification.');
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to accept verification: ' . $e->getMessage());
        }
    }

    /**
     * Dispute opponent verification
     */
    public function disputeVerification(Request $request, Challenge $challenge)
    {
        $user = auth()->user();

        // Check if user is a participant
        if (!$challenge->isUserParticipating($user)) {
            return redirect()->back()
                ->with('error', 'Only challenge participants can dispute results.');
        }

        // Check if there's a pending verification
        $escrow = $challenge->escrows()->first();
        if (!$escrow || $escrow->opponent_verification_status !== 'pending') {
            return redirect()->back()
                ->with('error', 'No pending verification found.');
        }

        // Check if user is from the losing team (opponent of winner)
        $participant = $challenge->participants()->where('user_id', $user->id)->first();
        if ($participant->team === $escrow->winner_team) {
            return redirect()->back()
                ->with('error', 'You cannot dispute your own win.');
        }

        try {
            $validated = $request->validate([
                'reason' => 'required|string|max:1000'
            ]);

            $ticket = $this->challengeService->disputeOpponentVerification($challenge, $user, $validated['reason']);

            return redirect()->route('challenges.user.show', $challenge)
                ->with('success', "Dispute submitted successfully! A support ticket ({$ticket->ticket_number}) has been created and our team will review it shortly.");
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to dispute verification: ' . $e->getMessage());
        }
    }
}
