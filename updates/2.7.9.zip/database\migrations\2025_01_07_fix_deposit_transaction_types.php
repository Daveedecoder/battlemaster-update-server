<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     * 
     * This migration fixes historical deposit transactions that were incorrectly
     * created with type='deposit' instead of type='credit'.
     */
    public function up(): void
    {
        DB::table('wallet_transactions')
            ->where('type', 'deposit')
            ->where(function ($query) {
                $query->where('description', 'like', '%Deposit%')
                      ->orWhere('description', 'like', '%deposit%');
            })
            ->update(['type' => 'credit']);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Revert credit back to deposit for rolled-back migration
        DB::table('wallet_transactions')
            ->where('type', 'credit')
            ->where(function ($query) {
                $query->where('description', 'like', '%Deposit%')
                      ->orWhere('description', 'like', '%deposit%');
            })
            ->update(['type' => 'deposit']);
    }
};
