<?php

namespace App\Http\Controllers\Payment;

use App\Http\Controllers\Controller;
use App\Models\PaymentMethod;
use App\Models\Transaction;
use App\Models\WalletTransaction;
use App\Models\Wallet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class StripeController extends Controller
{
    /**
     * Handle Stripe callback after successful payment
     */
    public function callback(Request $request)
    {
        $sessionId = $request->query('session_id');

        if (!$sessionId) {
            return redirect()->route('user.deposit')->with('error', 'Invalid payment session.');
        }

        // Get Stripe payment method configuration
        $payment = PaymentMethod::where('name', 'Stripe')->where('status', 'active')->first();

        if (!$payment || !$payment->stripe_secret_key) {
            return redirect()->route('user.deposit')->with('error', 'Payment method not configured.');
        }

        try {
            // Verify the Stripe session
            \Stripe\Stripe::setApiKey($payment->stripe_secret_key);
            $session = \Stripe\Checkout\Session::retrieve($sessionId);

            // Check if payment was successful
            if ($session->payment_status !== 'paid') {
                return redirect()->route('user.deposit')->with('error', 'Payment was not completed.');
            }

            // Get transaction reference from session metadata or custom_id
            $txRef = $session->metadata->tx_ref ?? null;

            if (!$txRef) {
                Log::error('Stripe callback: transaction reference not found', ['session_id' => $sessionId]);
                return redirect()->route('user.deposit')->with('error', 'Transaction reference not found.');
            }

            // Find the transaction
            $transaction = Transaction::where('reference', $txRef)->first();
            if (!$transaction) {
                Log::error('Stripe callback: transaction record not found', ['tx_ref' => $txRef]);
                return redirect()->route('user.deposit')->with('error', 'Transaction not found.');
            }

            $user = Auth::user();
            if ($transaction->user_id !== $user->id) {
                Log::warning('Stripe callback: user mismatch', [
                    'tx_ref' => $txRef,
                    'transaction_user' => $transaction->user_id,
                    'request_user' => $user->id
                ]);
                return redirect()->route('user.deposit')->with('error', 'User mismatch.');
            }

            $amount = $transaction->amount;
            $userCurrency = get_user_currency($user);

            // Get base currency (USD)
            $baseCurrency = \App\Models\Currency::where('code', 'USD')->first();
            if (!$baseCurrency) {
                Log::error('Base currency USD not found');
                return redirect()->route('user.deposit')->with('error', 'Base currency not configured.');
            }

            // Convert payment amount to base currency for wallet storage
            // Skip conversion if payment currency is already the base currency to avoid rounding errors
            if ($userCurrency->code === 'USD') {
                $amountInBaseCurrency = $amount;
            } else {
                $amountInBaseCurrency = convert_currency($amount, $userCurrency, $baseCurrency);
            }

            // Update transaction status
            $transaction->update(['status' => 'success']);

            // Add to wallet (stored in base currency)
            $wallet = Wallet::firstOrCreate(['user_id' => $user->id]);
            $wallet->increment('balance', $amountInBaseCurrency);

            // Create wallet transaction record with ORIGINAL amount in user's currency
            WalletTransaction::create([
                'user_id' => $user->id,
                'type' => 'credit',  // Deposits are credits to the user's wallet
                'amount' => $amount,  // Store original amount (5 EUR)
                'currency' => $userCurrency->code,
                'status' => 'completed',
                'reference' => $txRef,
                'description' => 'Deposit via Stripe',
            ]);

            // Format success message with user's currency
            $formattedAmount = format_currency_simple($amount, $userCurrency);
            return redirect()->route('user.deposit')->with('success', "{$formattedAmount} credited to your wallet successfully!");
        } catch (\Exception $e) {
            Log::error('Stripe callback error', [
                'session_id' => $sessionId,
                'error' => $e->getMessage()
            ]);
            return redirect()->route('user.deposit')->with('error', 'Payment verification failed: ' . $e->getMessage());
        }
    }
}
