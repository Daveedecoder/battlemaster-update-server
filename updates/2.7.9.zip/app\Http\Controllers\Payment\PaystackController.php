<?php

namespace App\Http\Controllers\Payment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PaymentMethod;
use App\Models\Transaction;
use App\Models\WalletTransaction;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\Wallet;

class PaystackController extends Controller
{
    public function depositPage()
    {
        $transactions = Transaction::where('user_id', Auth::id())->latest()->paginate(10);

        // Fetch active payment methods
        $paymentMethods = PaymentMethod::where('status', 'active')->pluck('name')->toArray();
        $hasPaystack = in_array('Paystack', $paymentMethods);
        $hasFlutterwave = in_array('Flutterwave', $paymentMethods);
        $hasStripe = in_array('Stripe', $paymentMethods);

        return view('user.wallet.deposit', compact('transactions', 'hasPaystack', 'hasFlutterwave', 'hasStripe'));
    }

    public function initiate(Request $request)
    {
        $user = Auth::user();
        $minAmount = get_min_deposit_amount($user);

        $request->validate([
            'amount' => "required|numeric|min:{$minAmount}",
        ]);

        $paystack = PaymentMethod::where('name', 'Paystack')->first();
        if (!$paystack) return back()->with('error', 'Paystack not configured.');

        $user = Auth::user();
        $userCurrency = get_user_currency($user);

        $amount = $request->amount;
        $email = $user->email;

        // Paystack amount is in smallest currency unit (cents for USD, pesewas for GHS, cents for ZAR)
        $amountInSmallestUnit = $amount * 100;

        $response = Http::withToken($paystack->paystack_secret_key)
            ->post('https://api.paystack.co/transaction/initialize', [
                'amount' => $amountInSmallestUnit,
                'email' => $email,
                'currency' => $userCurrency->code, // Use user's actual currency
                'callback_url' => route('paystack.verify'),
                'metadata' => [
                    'user_id' => $user->id,
                ],
            ]);

        $res = $response->json();

        if (isset($res['status']) && $res['status'] === true) {
            // Log pending transaction
            Transaction::create([
                'user_id' => Auth::id(),
                'reference' => $res['data']['reference'],
                'amount' => $amount,
                'status' => 'pending',
                'gateway' => 'Paystack',
            ]);

            return redirect($res['data']['authorization_url']);
        }

        // Check if error is due to unsupported currency
        if (isset($res['code']) && $res['code'] === 'unsupported_currency') {
            Log::warning('Paystack currency not enabled', [
                'currency' => $userCurrency->code,
                'amount' => $amount,
                'user_id' => $user->id
            ]);

            return back()->with('error', 'The currency ' . $userCurrency->code . ' is currently not available for Paystack deposits. Please change your currency or use another payment method.');
        }

        // Get error message from Paystack if available
        $errorMessage = $res['message'] ?? 'Unable to initialize payment.';
        Log::error('Paystack initialization failed', [
            'response' => $res,
            'currency' => $userCurrency->code,
            'amount' => $amount,
            'user_id' => $user->id
        ]);

        return back()->with('error', $errorMessage);
    }

    public function verify(Request $request)
    {
        $paystack = PaymentMethod::where('name', 'Paystack')->first();
        $reference = $request->reference;

        $response = Http::withToken($paystack->paystack_secret_key)
            ->get("https://api.paystack.co/transaction/verify/{$reference}");

        $res = $response->json();

        $transaction = Transaction::where('reference', $reference)->first();

        if (!$transaction) return redirect()->route('user.deposit')->with('error', 'Transaction not found.');

        if ($res['status'] && $res['data']['status'] == 'success') {
            // Amount is in smallest unit (kobo/pesewas/cents), divide by 100
            $amount = $res['data']['amount'] / 100;
            $paymentCurrency = $res['data']['currency'] ?? 'USD';
            $user = Auth::user();
            $userCurrency = get_user_currency($user);

            // Get base currency (the one with exchange_rate = 1.0 as set by admin)
            $baseCurrency = \App\Models\Currency::where('exchange_rate', 1.0000)->first();
            if (!$baseCurrency) {
                $baseCurrency = \App\Models\Currency::where('code', 'NGN')->first();
            }

            // Get payment currency model
            $paymentCurrencyModel = \App\Models\Currency::where('code', strtoupper($paymentCurrency))->first();
            if (!$paymentCurrencyModel) {
                $paymentCurrencyModel = $baseCurrency;
            }

            // Convert the deposit amount from payment currency to base currency
            // Skip conversion if payment currency is already the base currency to avoid rounding errors
            if ($paymentCurrencyModel->id === $baseCurrency->id) {
                $amountInBaseCurrency = $amount;
            } else {
                $amountInBaseCurrency = convert_currency($amount, $paymentCurrencyModel, $baseCurrency);
            }

            // Update transaction status
            $transaction->update(['status' => 'success']);

            // Credit wallet with the converted amount

            $wallet = Wallet::firstOrCreate(['user_id' => $user->id]);
            $wallet->increment('balance', $amountInBaseCurrency);

            // Do NOT update $user->wallet_balance directly. Wallet model is the source of truth.

            // Log wallet transaction for dashboard activity
            WalletTransaction::create([
                'user_id' => $user->id,
                'type' => 'credit',  // Deposits are credits to the user's wallet
                'amount' => $amount, // original payment amount
                'currency' => $paymentCurrencyModel->code,
                'status' => 'completed',
                'reference' => $reference,
                'description' => 'Deposit via Paystack',
            ]);

            // Format success message with user's currency
            $displayAmount = convert_currency($amountInBaseCurrency, $baseCurrency, $userCurrency);
            $formattedAmount = format_currency_simple($displayAmount, $userCurrency);
            return redirect()->route('user.deposit')->with('success', "{$formattedAmount} credited to your wallet successfully!");
        }

        // Check if transaction was cancelled by user
        if ($res['status'] && isset($res['data']['status']) && $res['data']['status'] == 'abandoned') {
            $transaction->update(['status' => 'cancelled']);

            Log::info('Paystack transaction cancelled by user', [
                'reference' => $reference,
                'user_id' => $transaction->user_id
            ]);

            return redirect()->route('user.deposit')->with('info', 'Transaction was cancelled by you. No charges were made.');
        }

        $transaction->update(['status' => 'failed']);
        return redirect()->route('user.deposit')->with('error', 'Payment verification failed.');
    }
}
