<?php

namespace App\Http\Controllers\Payment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PaymentMethod;
use App\Models\Transaction;
use App\Models\WalletTransaction;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\Wallet;

use Illuminate\Support\Str;

class FlutterwaveController extends Controller
{
    public function initiate(Request $request)
    {
        $user = Auth::user();
        $minAmount = get_min_deposit_amount($user);

        $request->validate([
            'amount' => "required|numeric|min:{$minAmount}",
        ]);

        // Get Flutterwave credentials
        $flutterwave = PaymentMethod::where('name', 'Flutterwave')->first();
        if (!$flutterwave) {
            return back()->with('error', 'Flutterwave not configured.');
        }

        // Get keys from model accessors (handles both credentials JSON and flat columns)
        $publicKey = $flutterwave->flutterwave_public_key;
        $secretKey = $flutterwave->flutterwave_secret_key;

        if (!$publicKey || !$secretKey) {
            Log::error('Flutterwave keys missing', ['publicKey' => $publicKey, 'secretKey' => $secretKey, 'flutterwave_record' => $flutterwave]);
            return back()->with('error', 'Flutterwave keys missing.');
        }

        $reference = 'FLW-' . strtoupper(uniqid());
        $amount = $request->amount;
        $user = Auth::user();
        $userCurrency = get_user_currency($user);

        // Flutterwave supported currencies
        $supportedCurrencies = ['USD', 'EUR', 'GBP', 'GHS', 'KES', 'ZAR', 'TZS', 'UGX', 'XAF', 'XOF', 'RWF'];
        if (!in_array(strtoupper($userCurrency->code), $supportedCurrencies)) {
            return back()->with('error', 'Flutterwave does not accept ' . $userCurrency->code . '. Please use another payment method or change your currency to one of these: ' . implode(', ', $supportedCurrencies) . '.');
        }

        // Create pending transaction
        Transaction::create([
            'user_id' => $user->id,
            'reference' => $reference,
            'amount' => $amount,
            'status' => 'pending',
            'gateway' => 'Flutterwave',
        ]);

        // Prepare payload for Flutterwave API
        // Use the callback route for redirect
        $callbackUrl = route('flutterwave.callback');

        $payload = [
            'tx_ref' => $reference,
            'amount' => $amount,
            'currency' => $userCurrency->code, // Use user's actual currency
            'redirect_url' => $callbackUrl,
            'payment_options' => 'card',
            'customer' => [
                'email' => $user->email,
                'name' => $user->name,
            ],
            'customizations' => [
                'title' => config('app.name') . ' Deposit',
                'description' => 'Deposit to wallet',
            ],
        ];

        $response = Http::withToken($secretKey)
            ->post('https://api.flutterwave.com/v3/payments', $payload);

        $res = $response->json();

        // Log full response for debugging
        Log::info('Flutterwave response', ['response' => $res, 'reference' => $reference, 'user_id' => $user->id]);

        // Flutterwave may return link under different keys depending on API/version
        $link = null;
        if (isset($res['status']) && ($res['status'] === 'success' || $res['status'] === true)) {
            if (!empty($res['data']['link'])) $link = $res['data']['link'];
            if (!$link && !empty($res['data']['payment_link'])) $link = $res['data']['payment_link'];
            if (!$link && !empty($res['data']['authorization_url'])) $link = $res['data']['authorization_url'];
            if (!$link && !empty($res['data']['meta']['authorization']['redirect'])) $link = $res['data']['meta']['authorization']['redirect'];
        }

        if ($link) {
            return redirect($link);
        }

        // Check if error is due to unsupported currency
        if (isset($res['message']) && (str_contains(strtolower($res['message']), 'currency') || str_contains(strtolower($res['message']), 'not supported'))) {
            Log::warning('Flutterwave currency not enabled', [
                'currency' => $userCurrency->code,
                'amount' => $amount,
                'user_id' => $user->id
            ]);

            return back()->with('error', 'The currency ' . $userCurrency->code . ' is currently not available for Flutterwave deposits. Please change your currency or use another payment method.');
        }

        // If there is an error message from API, show it
        $message = $res['message'] ?? ($res['status'] ?? 'Unable to initialize Flutterwave payment.');
        Log::error('Flutterwave initialization failed', [
            'response' => $res,
            'currency' => $userCurrency->code,
            'amount' => $amount,
            'user_id' => $user->id
        ]);

        return back()->with('error', $message);
    }

    /**
     * Handle Flutterwave redirect/callback and verify the transaction.
     */
    public function callback(Request $request)
    {
        $txRef = $request->query('tx_ref') ?? $request->query('txref') ?? $request->get('tx_ref');

        if (!$txRef) {
            return redirect()->route('user.deposit')->with('error', 'Transaction reference not provided.');
        }

        $flutterwave = PaymentMethod::where('name', 'Flutterwave')->first();
        if (!$flutterwave) return redirect()->route('user.deposit')->with('error', 'Flutterwave not configured.');

        // Get secret key from model accessor (handles both credentials JSON and flat columns)
        $secretKey = $flutterwave->flutterwave_secret_key;
        if (!$secretKey) {
            Log::error('Flutterwave keys missing on callback', ['tx_ref' => $txRef, 'flutterwave_record' => $flutterwave]);
            return redirect()->route('user.deposit')->with('error', 'Flutterwave keys missing.');
        }

        // Verify by reference (best-effort endpoint)
        $verifyUrl = "https://api.flutterwave.com/v3/transactions/verify_by_reference?tx_ref={$txRef}";
        $response = Http::withToken($secretKey)->get($verifyUrl);
        $res = $response->json();

        Log::info('Flutterwave verify response', ['response' => $res, 'tx_ref' => $txRef]);

        $transaction = Transaction::where('reference', $txRef)->first();
        if (!$transaction) return redirect()->route('user.deposit')->with('error', 'Transaction not found.');

        // Successful check
        $ok = false;
        if (!empty($res['status']) && $res['status'] === 'success' && !empty($res['data']['status']) && in_array($res['data']['status'], ['successful', 'success'])) {
            $ok = true;
        }

        if ($ok) {
            $amount = $res['data']['amount'] ?? $transaction->amount;
            $paymentCurrency = $res['data']['currency'] ?? 'USD';
            // Ensure amount is in main currency units
            if ($amount > 1000 && $amount > $transaction->amount) {
                // if API returns kobo, convert
                $amount = $amount / 100;
            }

            $user = Auth::user();
            $userCurrency = get_user_currency($user);

            // Get base currency (the one with exchange_rate = 1.0 as set by admin)
            $baseCurrency = \App\Models\Currency::where('exchange_rate', 1.0000)->first();
            if (!$baseCurrency) {
                $baseCurrency = \App\Models\Currency::where('code', 'NGN')->first();
            }

            // Get payment currency model
            $paymentCurrencyModel = \App\Models\Currency::where('code', strtoupper($paymentCurrency))->first();
            if (!$paymentCurrencyModel) {
                $paymentCurrencyModel = $baseCurrency;
            }

            // Convert payment amount to base currency for wallet storage
            // Skip conversion if payment currency is already the base currency to avoid rounding errors
            if ($paymentCurrencyModel->id === $baseCurrency->id) {
                $amountInBaseCurrency = $amount;
            } else {
                $amountInBaseCurrency = convert_currency($amount, $paymentCurrencyModel, $baseCurrency);
            }

            $transaction->update(['status' => 'success']);

            $wallet = Wallet::firstOrCreate(['user_id' => $user->id]);
            $wallet->increment('balance', $amountInBaseCurrency);

            // Do NOT update $user->wallet_balance directly. Wallet model is the source of truth.

            WalletTransaction::create([
                'user_id' => $user->id,
                'type' => 'credit',  // Deposits are credits to the user's wallet
                'amount' => $amount,  // Store original amount in user's currency (NOT converted)
                'currency' => $paymentCurrencyModel->code,
                'status' => 'completed',
                'reference' => $txRef,
                'description' => 'Deposit via Flutterwave',
            ]);

            // Format success message with user's currency
            $formattedAmount = format_currency_simple($amount, $userCurrency);
            return redirect()->route('user.deposit')->with('success', "{$formattedAmount} credited to your wallet successfully!");
        }

        // Check if transaction was cancelled by user
        if (!empty($res['data']['status']) && in_array($res['data']['status'], ['cancelled', 'canceled', 'abandoned'])) {
            $transaction->update(['status' => 'cancelled']);

            Log::info('Flutterwave transaction cancelled by user', [
                'reference' => $txRef,
                'user_id' => $transaction->user_id
            ]);

            return redirect()->route('user.deposit')->with('info', 'Transaction was cancelled by you. No charges were made.');
        }

        $transaction->update(['status' => 'failed']);
        return redirect()->route('user.deposit')->with('error', 'Payment verification failed.');
    }
}
