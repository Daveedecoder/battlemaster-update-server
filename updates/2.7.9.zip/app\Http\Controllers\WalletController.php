<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\WalletTransaction;

class WalletController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $wallet = $user->wallet;

        // Use wallet-specific transactions (WalletTransaction) instead of the general Transaction model
        $transactions = $user->walletTransactions()->latest()->paginate(10);

        // Calculate totals by converting each transaction to user's currency
        $userCurrency = $user->currency ?? \App\Models\Currency::where('code', 'USD')->first();
        $baseCurrency = \App\Models\Currency::where('code', 'USD')->first();
        
        $totalCredit = 0;
        $totalDebit = 0;
        
        foreach ($user->walletTransactions as $txn) {
            // Get the transaction currency (default to user's currency if not set)
            $txnCurrency = $txn->currency 
                ? \App\Models\Currency::where('code', $txn->currency)->first() 
                : $userCurrency;
            
            // Convert transaction amount to user's currency
            $amountInUserCurrency = convert_currency($txn->amount, $txnCurrency, $userCurrency);
            
            if ($txn->type == 'credit') {
                $totalCredit += $amountInUserCurrency;
            } else {
                $totalDebit += $amountInUserCurrency;
            }
        }

        // Debug: log actual wallet balance, user info, and what is being passed to the view
        \Log::debug('Wallet page detailed debug', [
            'user_id' => $user->id,
            'user_email' => $user->email,
            'wallet_id' => $wallet?->id,
            'wallet_balance' => $wallet?->balance,
            'wallet_db_row' => $wallet ? $wallet->toArray() : null,
            'sum_of_deposits' => $user->walletTransactions()->where('type', 'credit')->sum('amount'),
            'sum_of_withdrawals' => $user->walletTransactions()->where('type', 'debit')->sum('amount'),
            'view_wallet_balance' => $wallet?->balance,
        ]);

        return view('user.wallet.index', compact('wallet', 'transactions', 'totalCredit', 'totalDebit'));
    }
}