@extends('layouts.admin')

@section('title', 'Currency Management - ' . setting('site_name', 'Gaming Platform'))

@section('content')
<div class="container py-4">
    <h3 class="mb-4">
        <svg class="inline w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
        </svg>
        Currency Management
    </h3>

    @if(session('success'))
        <div class="alert alert-success rounded-3" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>{{ session('success') }}
        </div>
    @elseif(session('error'))
        <div class="alert alert-danger rounded-3" role="alert">
            <i class="bi bi-exclamation-circle-fill me-2"></i>{{ session('error') }}
        </div>
    @endif

    <!-- Validation Errors -->
    @if ($errors->any())
        <div class="alert alert-warning rounded-3" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <strong>Oops! Please fix the following errors:</strong>
            <ul class="mb-0 mt-2">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card border-0 shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center bg-gradient-primary text-white">
            <h5 class="mb-0">
                <i class="bi bi-currency-exchange me-2"></i>Exchange Rates Management
            </h5>
            <span class="badge bg-light text-dark">{{ count($currencies) }} Currencies</span>
        </div>

        <div class="card-body p-4">
            <p class="text-muted mb-4">
                <i class="bi bi-info-circle me-2"></i>
                Manage exchange rates for all supported currencies. All rates are relative to your preferred currency: 
                <strong>{{ $adminCurrency->code }} ({{ $adminCurrency->name }})</strong>.
                @if(!auth('admin')->user()->currency_id)
                    <br><span class="text-warning">
                        <i class="bi bi-exclamation-triangle me-1"></i>
                        You haven't set your preferred currency. Please update your profile settings first.
                    </span>
                @endif
            </p>

            @if(!auth('admin')->user()->currency_id)
                <div class="alert alert-warning">
                    <i class="bi bi-gear me-2"></i>
                    <strong>Setup Required:</strong> Please set your preferred currency in 
                    <a href="{{ route('admin.settings.index') }}" class="alert-link">Admin Settings</a> first.
                </div>
            @else
                <div class="alert alert-info mb-4">
                    <i class="bi bi-lightning-fill me-2"></i>
                    <strong>Live Rates:</strong> Exchange rates are automatically fetched from FreeCurrencyAPI when you refresh this page. Rates are cached for 1 hour.
                </div>

                <!-- FreeCurrencyAPI Key Configuration -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <h6 class="mb-0"><i class="bi bi-key me-2"></i>FreeCurrencyAPI Configuration</h6>
                        @if(!empty($currentApiKey))
                            <span class="badge bg-success">API Key Set</span>
                        @else
                            <span class="badge bg-warning text-dark">API Key Missing</span>
                        @endif
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.currencies.updateApiKey') }}" method="POST" class="row g-3">
                            @csrf
                            <div class="col-md-8">
                                <label class="form-label">FreeCurrencyAPI Key</label>
                                <input type="text" name="freecurrencyapi_key" class="form-control" placeholder="Enter your FreeCurrencyAPI key" value="{{ old('freecurrencyapi_key', $currentApiKey) }}" required>
                                <small class="form-text text-muted">Get a key at <a href="https://freecurrencyapi.com" target="_blank">freecurrencyapi.com</a>. The key is stored securely in the database.</small>
                            </div>
                            <div class="col-md-4 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="bi bi-save me-2"></i>Save API Key
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="row">
                        @foreach($currencies as $currency)
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="card border h-100 @if($currency->id === $adminCurrency->id) border-primary border-2 @endif">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="currency-symbol me-3 fs-2">
                                            {{ $currency->symbol }}
                                        </div>
                                        <div>
                                            <h5 class="mb-1">{{ $currency->code }}</h5>
                                            <small class="text-muted">{{ $currency->name }}</small>
                                            @if($currency->id === $adminCurrency->id)
                                                <span class="badge bg-primary ms-2">Your Base Currency</span>
                                            @endif
                                        </div>
                                    </div>

                                    @php
                                        $liveValue = $liveRates[$currency->code] ?? null;
                                        $displayRate = $liveValue ?? $currency->exchange_rate;
                                        $updatedText = $liveValue && $liveFetchedAt
                                            ? 'Live just now'
                                            : 'Last updated: ' . $currency->updated_at->diffForHumans();
                                    @endphp

                                    <div class="form-group">
                                        <label class="form-label">Exchange Rate</label>
                                        <div class="input-group">
                                            @if($currency->id !== $adminCurrency->id)
                                                <span class="input-group-text">1 {{ $adminCurrency->code }} =</span>
                                            @endif
                                            <input type="text" 
                                                   class="form-control" 
                                                   value="{{ number_format($displayRate, 4, '.', '') }}"
                                                   disabled
                                                   style="background-color: #f8f9fa; font-weight: 500;">
                                            @if($currency->id !== $adminCurrency->id)
                                                <span class="input-group-text">{{ $currency->code }}</span>
                                            @endif
                                        </div>
                                        @if($currency->id === $adminCurrency->id)
                                            <small class="form-text text-muted">Base currency rate is fixed at 1.0000</small>
                                        @else
                                            <small class="form-text text-muted">
                                                @if($liveValue)
                                                    Live rate from FreeCurrencyAPI (cached 1h)
                                                @else
                                                    Stored rate (live fetch unavailable)
                                                @endif
                                            </small>
                                        @endif
                                    </div>

                                    <div class="mt-3 pt-3 border-top">
                                        <small class="text-muted">
                                            <i class="bi bi-clock me-1"></i>
                                            {{ $updatedText }}
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
            @endif
        </div>
    </div>

</div>

<style>


.currency-symbol {
    font-weight: 600;
    color: #ffff;
}

.card:hover {
    transform: translateY(-2px);
    transition: transform 0.2s ease-in-out;
}

.input-group-text {
    font-size: 0.875rem;
    font-weight: 500;
}

.bg-gradient-primary {
    background: linear-gradient(135deg, #0d6efd, #0056b3);
}

.card-body h5 {
    color: #212529;
}

.card-body .text-muted {
    color: #6c757d !important;
}

.form-control {
    color: #212529 !important;
    background-color: #fff !important;
}

.form-control:focus {
    color: #212529 !important;
    background-color: #fff !important;
    border-color: #86b7fe !important;
    box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25) !important;
}

.form-control:disabled {
    color: #6c757d !important;
    background-color: #e9ecef !important;
}
</style>
@endsection