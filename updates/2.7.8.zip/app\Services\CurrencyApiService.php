<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class CurrencyApiService
{
    private $apiKey;
    private $baseUrl = 'https://api.freecurrencyapi.com/v1';
    private $cacheTime = 3600; // Cache for 1 hour

    public function __construct()
    {
        // Get API key from database only (no .env fallback)
        $this->apiKey = setting('freecurrencyapi_key');
    }

    /**
     * Get latest exchange rates for a base currency
     * 
     * @param string $baseCurrency The base currency (e.g., 'USD', 'EUR')
     * @param array $currencies Array of target currencies
     * @return array|null Exchange rates or null on error
     */
    public function getLatestRates($baseCurrency = 'USD', $currencies = ['USD', 'EUR'])
    {
        try {
            // Check if API key is configured
            if (empty($this->apiKey)) {
                Log::warning('FreeCurrencyAPI key not configured');
                return null;
            }

            $cacheKey = "currency_rates_{$baseCurrency}_" . implode('_', $currencies);

            // Try to get from cache first
            if (Cache::has($cacheKey)) {
                return Cache::get($cacheKey);
            }

            // Build request URL
            $url = $this->baseUrl . '/latest?apikey=' . $this->apiKey;
            $url .= '&base_currency=' . urlencode($baseCurrency);
            $url .= '&currencies=' . urlencode(implode(',', $currencies));

            // Make the request
            $response = file_get_contents($url);
            $data = json_decode($response, true);

            if (!isset($data['data'])) {
                Log::warning('FreeCurrencyAPI returned unexpected response', ['response' => $data]);
                return null;
            }

            // Cache the result
            Cache::put($cacheKey, $data['data'], $this->cacheTime);

            return $data['data'];
        } catch (\Exception $e) {
            Log::error('FreeCurrencyAPI error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Get historical exchange rates
     * 
     * @param string $date Date in YYYY-MM-DD format
     * @param string $baseCurrency The base currency
     * @param array $currencies Array of target currencies
     * @return array|null Historical rates or null on error
     */
    public function getHistoricalRates($date, $baseCurrency = 'USD', $currencies = ['USD', 'EUR'])
    {
        try {
            $cacheKey = "currency_historical_{$date}_{$baseCurrency}_" . implode('_', $currencies);

            if (Cache::has($cacheKey)) {
                return Cache::get($cacheKey);
            }

            $url = $this->baseUrl . '/historical?apikey=' . $this->apiKey;
            $url .= '&date=' . urlencode($date);
            $url .= '&base_currency=' . urlencode($baseCurrency);
            $url .= '&currencies=' . urlencode(implode(',', $currencies));

            $response = file_get_contents($url);
            $data = json_decode($response, true);

            if (!isset($data['data'])) {
                Log::warning('FreeCurrencyAPI historical returned unexpected response', ['response' => $data]);
                return null;
            }

            Cache::put($cacheKey, $data['data'], $this->cacheTime);
            return $data['data'];
        } catch (\Exception $e) {
            Log::error('FreeCurrencyAPI historical error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Convert amount from one currency to another
     * 
     * @param float $amount Amount to convert
     * @param string $fromCurrency Source currency
     * @param string $toCurrency Target currency
     * @return float|null Converted amount or null on error
     */
    public function convert($amount, $fromCurrency = 'USD', $toCurrency = 'EUR')
    {
        try {
            $rates = $this->getLatestRates($fromCurrency, [$toCurrency]);

            if (!$rates || !isset($rates[$toCurrency])) {
                return null;
            }

            return round($amount * $rates[$toCurrency], 2);
        } catch (\Exception $e) {
            Log::error('Currency conversion error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Get available currencies
     * 
     * @return array|null List of available currencies
     */
    public function getCurrencies()
    {
        try {
            $cacheKey = 'currency_list';

            if (Cache::has($cacheKey)) {
                return Cache::get($cacheKey);
            }

            $url = $this->baseUrl . '/currencies?apikey=' . $this->apiKey;
            $response = file_get_contents($url);
            $data = json_decode($response, true);

            if (!isset($data['data'])) {
                Log::warning('FreeCurrencyAPI currencies returned unexpected response', ['response' => $data]);
                return null;
            }

            // Cache for longer period as currencies don't change often
            Cache::put($cacheKey, $data['data'], 86400 * 7); // 7 days

            return $data['data'];
        } catch (\Exception $e) {
            Log::error('FreeCurrencyAPI currencies error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Get API status
     * 
     * @return array|null API status information
     */
    public function getStatus()
    {
        try {
            $url = $this->baseUrl . '/status?apikey=' . $this->apiKey;
            $response = file_get_contents($url);
            return json_decode($response, true);
        } catch (\Exception $e) {
            Log::error('FreeCurrencyAPI status error: ' . $e->getMessage());
            return null;
        }
    }
}
