<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminAuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\TransactionController;
use App\Http\Controllers\Admin\PaymentMethodController;
use App\Http\Controllers\Admin\WithdrawalController;
use App\Http\Controllers\Admin\ContentController;
use App\Http\Controllers\Admin\AddonController;
use App\Http\Controllers\Admin\CurrencyController;
use App\Http\Controllers\Admin\CustomizeController;
use App\Http\Controllers\Admin\MenuController;

Route::middleware(['prevent.access.not.installed'])->group(function () {

    // Admin Authentication Routes
    Route::middleware('guest:admin')->group(function () {
        Route::get('/login', [AdminAuthController::class, 'showLoginForm'])->name('admin.login');
        Route::post('/login', [AdminAuthController::class, 'login'])->name('admin.login.submit');
    });

    Route::middleware(['auth:admin'])->group(function () {
        Route::post('/logout', [AdminAuthController::class, 'logout'])->name('admin.logout');
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('admin.dashboard');
        Route::get('/dashboard/stats', [DashboardController::class, 'stats'])->name('admin.dashboard.stats');

        // User Management
        Route::get('/users', [UserController::class, 'index'])->name('admin.users.index');
        Route::get('/users/create', [UserController::class, 'create'])->name('admin.users.create');
        Route::post('/users', [UserController::class, 'store'])->name('admin.users.store');
        Route::get('/users/{user}/edit', [UserController::class, 'edit'])->name('admin.users.edit');
        Route::put('/users/{user}', [UserController::class, 'update'])->name('admin.users.update');
        Route::delete('/users/{user}', [UserController::class, 'destroy'])->name('admin.users.destroy');
        Route::patch('/users/{user}/toggle', [UserController::class, 'toggleStatus'])->name('admin.users.toggle');

        // Transaction Management
        Route::get('/transactions', [TransactionController::class, 'index'])->name('admin.transactions.index');
        Route::post('/transactions/{id}/approve', [TransactionController::class, 'approve'])->name('admin.transactions.approve');
        Route::post('/transactions/{id}/reject', [TransactionController::class, 'reject'])->name('admin.transactions.reject');

        // Wallet Management
        Route::get('/wallets', [App\Http\Controllers\Admin\WalletController::class, 'index'])->name('admin.wallets.index');
        Route::get('/wallets/credit/{id}', [App\Http\Controllers\Admin\WalletController::class, 'credit'])->name('admin.wallets.credit');
        Route::get('/wallets/debit/{id}', [App\Http\Controllers\Admin\WalletController::class, 'debit'])->name('admin.wallets.debit');
        Route::get('/wallets/history/{id}', [App\Http\Controllers\Admin\WalletController::class, 'history'])->name('admin.wallets.history');
        Route::post('/wallets/credit/{id}', [App\Http\Controllers\Admin\WalletController::class, 'creditStore'])->name('admin.wallets.credit.store');
        Route::post('/wallets/debit/{id}', [App\Http\Controllers\Admin\WalletController::class, 'debitStore'])->name('admin.wallets.debit.store');
        Route::get('/wallets/history', [App\Http\Controllers\Admin\WalletController::class, 'historyAll'])->name('admin.wallets.history.all');

        // Payment Methods Management
        Route::resource('payment_methods', PaymentMethodController::class, ['as' => 'admin']);
        Route::patch('payment_methods/{payment_method}/toggle', [PaymentMethodController::class, 'toggle'])->name('admin.payment_methods.toggle');

        // Reports
        Route::get('/reports', [App\Http\Controllers\Admin\ReportController::class, 'index'])->name('admin.reports.index');
        Route::get('/transactions/export', [App\Http\Controllers\Admin\TransactionController::class, 'export'])->name('admin.transactions.export');

        // Withdrawals Management
        Route::get('/withdrawals', [App\Http\Controllers\Admin\WithdrawalController::class, 'index'])->name('admin.withdrawals.index');
        Route::get('/withdrawals/{id}/{status}', [App\Http\Controllers\Admin\WithdrawalController::class, 'updateStatus'])->name('admin.withdrawals.status');

        // Settings Management
        Route::get('/settings', [App\Http\Controllers\Admin\SettingController::class, 'index'])->name('admin.settings.index');
        Route::post('/settings', [App\Http\Controllers\Admin\SettingController::class, 'update'])->name('admin.settings.update');
        Route::post('/settings/update-profile', [App\Http\Controllers\Admin\SettingController::class, 'updateProfile'])->name('admin.settings.updateProfile');
        Route::post('/settings/security', [App\Http\Controllers\Admin\SettingController::class, 'updateSecurity'])->name('admin.settings.security');

        // Currency Management
        Route::get('/currencies', [CurrencyController::class, 'index'])->name('admin.currencies.index');
        Route::post('/currencies/update', [CurrencyController::class, 'update'])->name('admin.currencies.update');
        Route::post('/currencies/api-key', [CurrencyController::class, 'updateApiKey'])->name('admin.currencies.updateApiKey');

        // KYC Verification Management
        Route::prefix('kyc')->name('admin.kyc.')->group(function () {
            Route::get('/', [App\Http\Controllers\Admin\KycVerificationController::class, 'index'])->name('index');
            Route::get('/{kyc}', [App\Http\Controllers\Admin\KycVerificationController::class, 'show'])->name('show');
            Route::get('/{kyc}/document/{type}', [App\Http\Controllers\Admin\KycVerificationController::class, 'viewDocument'])->name('document');
            Route::post('/{kyc}/approve', [App\Http\Controllers\Admin\KycVerificationController::class, 'approve'])->name('approve');
            Route::post('/{kyc}/reject', [App\Http\Controllers\Admin\KycVerificationController::class, 'reject'])->name('reject');
            Route::post('/{kyc}/reset', [App\Http\Controllers\Admin\KycVerificationController::class, 'reset'])->name('reset');
        });

        // Escrow Management
        Route::get('/escrows', [App\Http\Controllers\Admin\EscrowController::class, 'index'])->name('admin.escrows.index');
        Route::post('/escrows/{escrow}/release', [App\Http\Controllers\Admin\EscrowController::class, 'release'])->name('admin.escrows.release');
        Route::post('/escrows/{escrow}/refund', [App\Http\Controllers\Admin\EscrowController::class, 'refund'])->name('admin.escrows.refund');

        // Proof Viewing
        Route::get('/proof/{filename}', [App\Http\Controllers\Admin\ProofController::class, 'view'])->name('admin.proof.view');

        // Content Management
        Route::resource('contents', ContentController::class, ['as' => 'admin']);
        Route::patch('contents/{content}/toggle', [ContentController::class, 'toggle'])->name('admin.contents.toggle');
        Route::post('contents/sort', [ContentController::class, 'updateSort'])->name('admin.contents.sort');
        Route::post('contents/upload-image', [ContentController::class, 'uploadImage'])->name('admin.contents.upload-image');

        // Content Pages - Page Builder within Content Management
        Route::prefix('content')->group(function () {
            Route::resource('pages', App\Http\Controllers\Admin\ContentPageController::class, [
                'as' => 'admin.content',
                'names' => [
                    'index' => 'admin.content-pages.index',
                    'create' => 'admin.content-pages.create',
                    'store' => 'admin.content-pages.store',
                    'show' => 'admin.content-pages.show',
                    'edit' => 'admin.content-pages.edit',
                    'update' => 'admin.content-pages.update',
                    'destroy' => 'admin.content-pages.destroy',
                ]
            ]);
        });

        // Page Editor - Visual Frontend Editor
        Route::get('page-editor', [App\Http\Controllers\Admin\PageEditorController::class, 'index'])->name('admin.page-editor.index');
        Route::get('page-editor/{page}/edit', [App\Http\Controllers\Admin\PageEditorController::class, 'edit'])->name('admin.page-editor.edit');
        Route::get('page-editor/{page}/preview', [App\Http\Controllers\Admin\PageEditorController::class, 'preview'])->name('admin.page-editor.preview');
        Route::post('page-editor/update-block', [App\Http\Controllers\Admin\PageEditorController::class, 'updateBlock'])->name('admin.page-editor.update-block');
        Route::post('page-editor/upload-image', [App\Http\Controllers\Admin\PageEditorController::class, 'uploadImage'])->name('admin.page-editor.upload-image');
        Route::post('page-editor/clear-cache', [App\Http\Controllers\Admin\PageEditorController::class, 'clearCache'])->name('admin.page-editor.clear-cache');

        // Addon Management
        Route::get('/addons', [App\Http\Controllers\Admin\AddonController::class, 'index'])->name('admin.addons.index');
        Route::get('/addons/upload', [App\Http\Controllers\Admin\AddonController::class, 'upload'])->name('admin.addons.upload');
        Route::post('/addons', [App\Http\Controllers\Admin\AddonController::class, 'store'])->name('admin.addons.store');
        Route::get('/addons/{addon}/thumbnail', [App\Http\Controllers\Admin\AddonController::class, 'thumbnail'])->name('admin.addons.thumbnail');
        Route::patch('/addons/{addon}/activate', [App\Http\Controllers\Admin\AddonController::class, 'activate'])->name('admin.addons.activate');
        Route::patch('/addons/{addon}/deactivate', [App\Http\Controllers\Admin\AddonController::class, 'deactivate'])->name('admin.addons.deactivate');
        Route::delete('/addons/{addon}', [App\Http\Controllers\Admin\AddonController::class, 'destroy'])->name('admin.addons.destroy');

        // Support Ticket Management
        Route::prefix('support')->name('admin.support.')->group(function () {
            Route::get('/', [App\Http\Controllers\Admin\SupportTicketController::class, 'index'])->name('index');
            Route::get('/{ticket}', [App\Http\Controllers\Admin\SupportTicketController::class, 'show'])->name('show');
            Route::post('/{ticket}/reply', [App\Http\Controllers\Admin\SupportTicketController::class, 'reply'])->name('reply');
            Route::post('/{ticket}/status', [App\Http\Controllers\Admin\SupportTicketController::class, 'updateStatus'])->name('updateStatus');
            Route::post('/{ticket}/assign', [App\Http\Controllers\Admin\SupportTicketController::class, 'assign'])->name('assign');
            Route::post('/{ticket}/priority', [App\Http\Controllers\Admin\SupportTicketController::class, 'updatePriority'])->name('updatePriority');
        });

        // Appearance Management
        Route::prefix('appearance')->name('admin.appearance.')->group(function () {
            // Customize
            Route::get('/customize', [CustomizeController::class, 'index'])->name('customize');
            Route::post('/customize', [CustomizeController::class, 'update'])->name('customize.update');
            Route::post('/customize/setting', [CustomizeController::class, 'updateSetting'])->name('customize.setting');
            Route::post('/customize/reset', [CustomizeController::class, 'reset'])->name('customize.reset');

            // Menus
            Route::get('/menus', [MenuController::class, 'index'])->name('menus.index');
            Route::put('/menus/{menu}', [MenuController::class, 'update'])->name('menus.update');
        });

        // System Update Management
        Route::prefix('system')->name('admin.system.')->group(function () {
            Route::get('/update', [App\Http\Controllers\Admin\UpdateController::class, 'index'])->name('update');
            Route::post('/update/check', [App\Http\Controllers\Admin\UpdateController::class, 'checkForUpdates'])->name('update.check');
            Route::post('/update/apply/{version}', [App\Http\Controllers\Admin\UpdateController::class, 'applyUpdate'])->name('update.apply');
            Route::get('/update/progress', [App\Http\Controllers\Admin\UpdateController::class, 'getProgress'])->name('update.progress');
            Route::post('/update/rollback/{version}', [App\Http\Controllers\Admin\UpdateController::class, 'rollback'])->name('update.rollback');
        });
    });
});