<header class="bg-gradient-to-r from-gray-900 to-gray-800 p-6 shadow-lg border-b border-gray-700">
    <div class="max-w-7xl mx-auto flex justify-between items-center">
        <div class="space-y-1">
            <div class="flex items-center space-x-2">
                <h1 class="text-2xl font-bold text-white">Welcome back,</h1>
                <span class="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
                    {{ Auth::user()->name }}
                </span>
                <span class="animate-wave">👋</span>
            </div>
            <p class="text-sm text-gray-400 font-medium">Experience the next level of gaming</p>
        </div>

        <div class="flex items-center space-x-6">
            <div class="bg-gray-700 rounded-lg px-4 py-2 flex items-center space-x-2">
                <span class="text-yellow-400">💳</span>
                <span class="text-white font-medium">{{ format_user_currency(Auth::user()->wallet->balance) }}</span>
            </div>
            
            <div class="relative">
                <img 
                    src="{{ Auth::user()->avatar_url ?? asset('assets/img/default-avatar.png') }}" 
                    class="w-12 h-12 rounded-full border-2 border-blue-500 hover:border-purple-500 transition-colors duration-300 object-cover" 
                    alt="{{ Auth::user()->name }}'s Avatar"
                >
                <div class="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-gray-900"></div>
            </div>
        </div>
    </div>
</header>

<style>
    @keyframes wave {
        0% { transform: rotate(0deg); }
        20% { transform: rotate(-15deg); }
        40% { transform: rotate(15deg); }
        60% { transform: rotate(-15deg); }
        80% { transform: rotate(15deg); }
        100% { transform: rotate(0deg); }
    }
    .animate-wave {
        display: inline-block;
        animation: wave 2s ease-in-out infinite;
    }
</style>
