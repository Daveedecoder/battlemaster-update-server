<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class WithdrawalSuccessfulNotification extends Notification
{
    use Queueable;

    public function __construct(public float $amount, public string $currency = 'USD') {}

    public function via($notifiable)
    {
        return ['mail'];
    }

    public function toMail($notifiable)
    {
        $currencyModel = \App\Models\Currency::where('code', $this->currency)->first();
        $formattedAmount = $currencyModel ? $currencyModel->formatAmount($this->amount) : $this->currency . ' ' . number_format($this->amount, 2);
        return (new MailMessage)
            ->subject('Withdrawal Processed 💸')
            ->greeting('Hello ' . $notifiable->name . ',')
            ->line('Your withdrawal of ' . $formattedAmount . ' has been processed successfully.')
            ->line('Funds should reflect in your account soon.')
            ->action('View Transactions', url('/wallet/transactions'))
            ->salutation('Regards, ' . config('app.name') . ' Team');
    }
}

