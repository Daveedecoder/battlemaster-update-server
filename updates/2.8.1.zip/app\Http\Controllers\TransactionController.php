<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class TransactionController extends Controller
{
    // Show all user's transactions
    public function index()
    {
        $transactions = Transaction::where('user_id', Auth::id())
            ->latest()
            ->paginate(10);

        return view('user.transactions.index', compact('transactions'));
    }

    // Show Deposit/Withdraw form
    public function create()
    {
        return view('user.transactions.create');
    }

    // Handle Deposit/Withdraw
    public function store(Request $request)
    {
        $user = Auth::user();

        // Check if user is suspended
        if ($user->status === 'suspended') {
            return back()->with('error', 'Your account is suspended. Deposits and withdrawals are not allowed. Please contact support.');
        }

        $request->validate([
            'type' => 'required|in:deposit,withdrawal',
            'amount' => 'required|numeric|min:1',
        ]);

        // Ensure the user has a wallet (older users might not have one)
        $wallet = $user->wallet;
        if (!$wallet) {
            $wallet = $user->wallet()->create([
                'balance' => 0.00,
            ]);
        }

        DB::beginTransaction();

        try {
            $reference = strtoupper(Str::random(10));

            if ($request->type === 'withdrawal') {
                if (($wallet->balance ?? 0) < $request->amount) {
                    return back()->with('error', '❌ Insufficient wallet balance for withdrawal.');
                }

                // Deduct funds
                $wallet->decrement('balance', $request->amount);
            } else {
                // Add funds
                $wallet->increment('balance', $request->amount);
            }

            // Refresh model so $wallet->balance reflects DB changes made by increment/decrement
            $wallet->refresh();

            // Record transaction
            $formattedAmount = format_user_currency($request->amount, $user);
            $formattedBalance = format_user_currency($wallet->balance, $user);
            Transaction::create([
                'user_id' => $user->id,
                'type' => $request->type,
                'amount' => $request->amount,
                'status' => 'approved', // can later make this pending for admin review
                'reference' => $reference,
                'description' => ucfirst($request->type) . ' of ' . $formattedAmount,
            ]);

            DB::commit();

            return redirect()->route('user.transactions.index')
                ->with('success', ucfirst($request->type) . ' successful! New Balance: ' . $formattedBalance);
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Something went wrong: ' . $e->getMessage());
        }
    }
}