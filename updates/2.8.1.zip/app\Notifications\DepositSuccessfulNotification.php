<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class DepositSuccessfulNotification extends Notification
{
    use Queueable;

    public function __construct(public float $amount, public string $currency = 'USD') {}

    public function via($notifiable)
    {
        return ['mail'];
    }

    public function toMail($notifiable)
    {
        $currencyModel = \App\Models\Currency::where('code', $this->currency)->first();
        $formattedAmount = $currencyModel ? $currencyModel->formatAmount($this->amount) : $this->currency . ' ' . number_format($this->amount, 2);
        return (new MailMessage)
            ->subject('Deposit Successful 💰')
            ->greeting('Hello ' . $notifiable->name . ',')
            ->line('Your deposit of ' . $formattedAmount . ' was successful.')
            ->line('Your new wallet balance is now updated in your account.')
            ->action('View Wallet', url('/wallet'))
            ->salutation('Thank you for using ' . config('app.name') . '!');
    }
}

