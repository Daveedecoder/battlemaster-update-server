<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Exception;
use Symfony\Component\Process\Process;

class UpdateController extends Controller
{
	// ...existing methods...

    /**
     * Download update package from server
     */
    protected function downloadUpdate($version)
    {
        $args = func_get_args();
        $downloadUrl = $args[1] ?? null;
        $tempPath = config('update.temp_path');

        // Ensure temp directory exists
        if (!File::exists($tempPath)) {
            File::makeDirectory($tempPath, 0755, true);
        }

        $zipPath = $tempPath . '/update-' . $version . '.zip';

        // Use provided download URL or fallback to cache
        if (!$downloadUrl) {
            $versionInfo = cache('latest_version_info');
            if (!$versionInfo || !isset($versionInfo['download_url'])) {
                throw new Exception('Download URL not found. Please check for updates first.');
            }
            $downloadUrl = $versionInfo['download_url'];
        }

        Log::info('Attempting to download update', [
            'url' => $downloadUrl,
            'version' => $version,
            'temp_path' => $zipPath
        ]);

        // Download with streaming and aggressive SSL configuration for XAMPP
        $response = Http::withOptions([
            'verify' => false,
            'connect_timeout' => 120,
            'timeout' => config('update.timeout', 600),
            'http_errors' => false,
            'headers' => ['User-Agent' => 'BattleMaster-Updater/2.6'],
            'curl' => [
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_CONNECTTIMEOUT => 120,
                CURLOPT_TIMEOUT => config('update.timeout', 600),
                CURLOPT_SSLVERSION => CURL_SSLVERSION_TLSv1_2,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            ]
        ])->timeout(config('update.timeout', 600))->sink($zipPath)->get($downloadUrl);

        if (!$response->successful()) {
            Log::error('Download failed', [
                'status' => $response->status(),
                'url' => $downloadUrl
            ]);
            throw new Exception('Failed to download update: HTTP ' . $response->status());
        }

        Log::info('Download completed', ['file_size' => File::size($zipPath)]);

        return $zipPath;
    }

    /**
     * Get update progress (stub implementation)
     */
    public function getProgress(Request $request)
    {
        // You can enhance this to return real progress if needed
        return response()->json([
            'status' => 'idle',
            'progress' => 100,
            'message' => 'No update in progress.'
        ]);
    }

    /**
     * SEQUENTIAL UPDATE: Get the next required update version
     * Returns first version > current (for forced sequential updates)
     */
    protected function getNextSequentialVersion($allVersions, $currentVersion)
    {
        // Sort versions ascending (oldest first) for proper sequencing
        $sorted = $allVersions->sort(function ($a, $b) {
            return version_compare($a['version'] ?? '0.0.0', $b['version'] ?? '0.0.0');
        });

        // Find FIRST version greater than current (next sequential)
        foreach ($sorted as $version) {
            if (version_compare($version['version'] ?? '0.0.0', $currentVersion, '>')) {
                return $version;
            }
        }

        return null; // Already on latest
    }

    /**
     * Show the update system page
     */
    public function index(Request $request)
    {
        // Get current version from config (reads from .env APP_VERSION)
        $currentVersion = config('update.current_version', env('APP_VERSION', '1.0.0'));
        $systemName = config('app.name', 'BattleMaster');
        $lastCheck = cache('last_update_check');
        $updateAvailable = false;

        // Fetch all available updates from GitHub-hosted version.json
        try {
            $apiUrl = config('update.api_url');

            // GitHub raw files don't support query parameters
            // Fetch version.json directly
            // Cache-buster avoids stale CDN responses
            $versionJsonUrl = $apiUrl . '/version.json?cb=' . time();

            Log::info('Fetching updates from GitHub', ['url' => $versionJsonUrl]);

            $response = Http::withOptions([
                'verify' => false,
                'connect_timeout' => 120,
                'timeout' => 300,
                'http_errors' => false,
                'headers' => ['User-Agent' => 'BattleMaster-Updater/2.6'],
                'curl' => [
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => 0,
                    CURLOPT_SSLVERSION => CURL_SSLVERSION_TLSv1_2,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                ]
            ])->timeout(300)->retry(2, 100)->get($versionJsonUrl);

            $versions = collect();

            if ($response->successful()) {
                // Robust JSON decode (handles BOM/whitespace/invalid UTF-8)
                $rawBody = $response->body();
                // Strip BOM if present
                if (substr($rawBody, 0, 3) === "\xEF\xBB\xBF") {
                    $rawBody = substr($rawBody, 3);
                }
                $data = json_decode($rawBody, true, 512, JSON_INVALID_UTF8_IGNORE);

                if (!is_array($data) || empty($data)) {
                    Log::warning('version.json parse returned empty', [
                        'status' => $response->status(),
                        'body_length' => strlen($rawBody),
                        'body_sample' => substr($rawBody, 0, 500)
                    ]);
                    $data = [];
                }

                Log::info('GitHub version data received', [
                    'latest_version' => $data['latest_version'] ?? 'unknown',
                    'versions_count' => count($data['versions'] ?? []),
                    'status' => $response->status()
                ]);

                $versions = collect($data['versions'] ?? []);
            } else {
                Log::error('Failed to fetch version.json from GitHub', [
                    'status' => $response->status(),
                    'url' => $versionJsonUrl
                ]);
            }

            // Add status to each version and keep all history (newer, current, older)
            $allAvailableUpdates = $versions->map(function ($version) use ($currentVersion) {
                $versionNumber = $version['version'] ?? null;

                if (!$versionNumber) {
                    return $version;
                }

                $comparison = version_compare($versionNumber, $currentVersion);

                if ($comparison > 0) {
                    // Newer version - can be installed
                    $version['local_status'] = null; // Show install button
                    $version['status_text'] = 'Available';
                } elseif ($comparison === 0) {
                    // Current version
                    $version['local_status'] = 'installed';
                    $version['status_text'] = 'Installed';
                } else {
                    // Older version - already installed (current version is higher)
                    $version['local_status'] = 'completed';
                    $version['status_text'] = 'Installed';
                }

                return $version;
            })
                // Sort by version (ascending - oldest first for proper sequencing)
                ->sort(function ($a, $b) {
                    return version_compare($a['version'] ?? '0.0.0', $b['version'] ?? '0.0.0');
                })
                ->values();

            // Get ONLY the next sequential version (SEQUENTIAL UPDATE REQUIREMENT)
            $nextVersion = $this->getNextSequentialVersion($allAvailableUpdates, $currentVersion);
            $updateAvailable = $nextVersion !== null;
        } catch (Exception $e) {
            Log::error('Failed to fetch updates', ['error' => $e->getMessage()]);
            $allAvailableUpdates = collect();
            $nextVersion = null;
        }

        // Paginate if needed
        $page = $request->get('page', 1);
        $perPage = 10;
        $allAvailableUpdates = new \Illuminate\Pagination\LengthAwarePaginator(
            $allAvailableUpdates->forPage($page, $perPage),
            $allAvailableUpdates->count(),
            $perPage,
            $page,
            ['path' => $request->url(), 'query' => $request->query()]
        );

        return view('admin.system.update', compact('currentVersion', 'systemName', 'lastCheck', 'updateAvailable', 'allAvailableUpdates', 'nextVersion'));
    }

    /**
     * Check for updates from GitHub-hosted version.json
     */
    public function checkForUpdates(Request $request)
    {
        try {
            $currentVersion = config('update.current_version', config('app.version', '1.0.0'));

            // Fetch version.json from GitHub (use same resilient SSL options as other calls)
            // Cache-buster avoids stale CDN responses
            $versionJsonUrl = config('update.api_url') . '/version.json?cb=' . time();
            $response = Http::withOptions([
                'verify' => false,
                'connect_timeout' => 120,
                'timeout' => 300,
                'http_errors' => false,
                'headers' => ['User-Agent' => 'BattleMaster-Updater/2.6'],
                'curl' => [
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => 0,
                    CURLOPT_SSLVERSION => CURL_SSLVERSION_TLSv1_2,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                ]
            ])->timeout(300)->retry(2, 100)->get($versionJsonUrl);

            if ($response->successful()) {
                // Robust JSON decode (handles BOM/whitespace/invalid UTF-8)
                $rawBody = $response->body();
                if (substr($rawBody, 0, 3) === "\xEF\xBB\xBF") {
                    $rawBody = substr($rawBody, 3);
                }
                $data = json_decode($rawBody, true, 512, JSON_INVALID_UTF8_IGNORE);
                if (!is_array($data) || empty($data)) {
                    Log::warning('version.json parse returned empty (checkForUpdates)', [
                        'status' => $response->status(),
                        'body_length' => strlen($rawBody),
                        'body_sample' => substr($rawBody, 0, 500)
                    ]);
                    $data = [];
                }
                $latestVersion = $data['latest_version'] ?? $currentVersion;
                $updateAvailable = version_compare($latestVersion, $currentVersion, '>');

                cache(['last_update_check' => now()], now()->addHours(24));

                return response()->json([
                    'success' => true,
                    'update_available' => $updateAvailable,
                    'latest_version' => $latestVersion,
                    'current_version' => $currentVersion,
                    'message' => $updateAvailable ? 'Update available!' : 'System is up to date.'
                ]);
            }

            return response()->json([
                'success' => false,
                'message' => 'Failed to connect to GitHub update server.'
            ], 500);
        } catch (Exception $e) {
            Log::error('Check updates failed', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Apply an update
     */
    public function applyUpdate(Request $request, $version)
    {
        try {
            // Get current version
            $currentVersion = config('update.current_version', config('app.version', '1.0.0'));

            // Get version-specific metadata from GitHub
            // Fetch the version.json file to get metadata for the SPECIFIC version
            $metadataUrl = config('update.api_url') . '/updates/' . $version . '.json';

            Log::info('Fetching metadata from GitHub', [
                'url' => $metadataUrl,
                'version' => $version
            ]);

            $metadataResponse = Http::withOptions([
                'verify' => false,
                'connect_timeout' => 120,
                'timeout' => 300,
                'http_errors' => false,
                'headers' => ['User-Agent' => 'BattleMaster-Updater/2.6'],
                'curl' => [
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => 0,
                    CURLOPT_SSLVERSION => CURL_SSLVERSION_TLSv1_2,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                ]
            ])->timeout(300)->retry(2, 100)->get($metadataUrl);

            if (!$metadataResponse->successful()) {
                Log::error('Failed to fetch metadata for version', [
                    'version' => $version,
                    'url' => $metadataUrl,
                    'status' => $metadataResponse->status()
                ]);
                throw new Exception('Failed to fetch update metadata for version ' . $version . ' from GitHub');
            }

            // Robust JSON decode (handles BOM/whitespace/invalid UTF-8)
            $rawBody = $metadataResponse->body();
            if (substr($rawBody, 0, 3) === "\xEF\xBB\xBF") {
                $rawBody = substr($rawBody, 3);
            }
            $metadata = json_decode($rawBody, true, 512, JSON_INVALID_UTF8_IGNORE);

            if (!is_array($metadata) || empty($metadata)) {
                Log::error('Metadata parse returned empty', [
                    'version' => $version,
                    'status' => $metadataResponse->status(),
                    'body_length' => strlen($rawBody),
                    'body_sample' => substr($rawBody, 0, 500)
                ]);
                throw new Exception('Failed to parse metadata for version ' . $version);
            }

            if (!isset($metadata['download_url'])) {
                Log::error('Download URL missing from metadata', [
                    'version' => $version,
                    'metadata' => $metadata
                ]);
                throw new Exception('Download URL not found in metadata for version ' . $version);
            }

            // Verify the metadata version matches the requested version
            if (isset($metadata['version']) && $metadata['version'] !== $version) {
                Log::warning('Metadata version mismatch', [
                    'requested' => $version,
                    'received' => $metadata['version']
                ]);
            }

            // ====== SEQUENTIAL UPDATE SECURITY CHECK ======
            // Verify the requested version is the NEXT sequential one
            // Fetch version.json from GitHub
            // Cache-buster to avoid stale CDN responses
            $versionJsonUrl = config('update.api_url') . '/version.json?cb=' . time();
            $allVersionsResponse = Http::withOptions([
                'verify' => false,
                'connect_timeout' => 120,
                'timeout' => 300,
                'http_errors' => false,
                'headers' => ['User-Agent' => 'BattleMaster-Updater/2.6'],
                'curl' => [
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => 0,
                    CURLOPT_SSLVERSION => CURL_SSLVERSION_TLSv1_2,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                ]
            ])->timeout(300)->retry(2, 100)->get($versionJsonUrl);

            if ($allVersionsResponse->successful()) {
                $rawBody = $allVersionsResponse->body();
                if (substr($rawBody, 0, 3) === "\xEF\xBB\xBF") {
                    $rawBody = substr($rawBody, 3);
                }
                $allVersionsData = json_decode($rawBody, true, 512, JSON_INVALID_UTF8_IGNORE);

                if (!is_array($allVersionsData) || empty($allVersionsData)) {
                    Log::warning('version.json parse returned empty (security check)', [
                        'status' => $allVersionsResponse->status(),
                        'body_length' => strlen($rawBody),
                        'body_sample' => substr($rawBody, 0, 500)
                    ]);
                    $allVersionsData = [];
                }

                $allVersions = collect($allVersionsData['versions'] ?? []);

                // Get the next required version
                $nextVersion = $this->getNextSequentialVersion($allVersions, $currentVersion);

                if ($nextVersion === null) {
                    // If API is empty but requested version is greater, allow it
                    if (version_compare($version, $currentVersion, '>')) {
                        $nextVersion = ['version' => $version];
                    } else {
                        return response()->json([
                            'success' => false,
                            'message' => 'Already on latest version'
                        ], 400);
                    }
                }

                // SECURITY: Verify requested version matches the NEXT sequential version
                if ($version !== ($nextVersion['version'] ?? null)) {
                    Log::warning('Update skipping attempt blocked', [
                        'current_version' => $currentVersion,
                        'requested_version' => $version,
                        'next_allowed_version' => $nextVersion['version'] ?? null
                    ]);

                    return response()->json([
                        'success' => false,
                        'message' => "Sequential updates required. You must update to v{$nextVersion['version']} first. Skipping versions is not allowed.",
                        'current_version' => $currentVersion,
                        'required_version' => $nextVersion['version'] ?? null,
                        'requested_version' => $version
                    ], 403);
                }
            }
            // ====== END SECURITY CHECK ======

            $downloadUrl = $metadata['download_url'];

            // Download and apply update
            $zipPath = $this->downloadUpdate($version, $downloadUrl);

            // Enable maintenance mode
            if (config('update.enable_maintenance')) {
                Artisan::call('down', ['--secret' => 'admin-secret']);
            }

            // Extract update
            $zip = new \ZipArchive();
            if ($zip->open($zipPath) === true) {
                Log::info('Extracting update package to base path', ['path' => base_path()]);
                $zip->extractTo(base_path());
                $zip->close();
                Log::info('Update package extracted successfully');
            } else {
                throw new Exception('Failed to extract update package');
            }

            // Run migrations if needed
            if ($metadata['migration_required'] ?? false) {
                Log::info('Running database migrations...');
                Artisan::call('migrate', ['--force' => true]);
                Log::info('Database migrations completed');
            }

            // Update version in .env
            Log::info('Updating .env APP_VERSION to ' . $version);
            $this->updateEnvVersion($version);

            // Cleanup ZIP file
            if (File::exists($zipPath)) {
                File::delete($zipPath);
            }

            Log::info('Update completed successfully');

            // Send response FIRST before cache clearing
            $response = response()->json([
                'success' => true,
                'version' => $version,
                'message' => 'Update applied successfully!'
            ]);

            // Send response to browser immediately
            $response->send();

            // Flush output buffers and close connection
            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            } else {
                // Fallback for non-FastCGI environments
                if (ob_get_level() > 0) {
                    ob_end_flush();
                }
                flush();
            }

            // Now clear caches AFTER response sent (won't block user)
            Log::info('Clearing Laravel caches...');
            try {
                Artisan::call('config:clear');
                Artisan::call('cache:clear');
                Artisan::call('view:clear');
                Artisan::call('route:clear');
                Log::info('All caches cleared successfully');
            } catch (Exception $cacheException) {
                Log::warning('Cache clearing error', ['error' => $cacheException->getMessage()]);
            }

            // Disable maintenance mode
            if (config('update.enable_maintenance')) {
                Artisan::call('up');
            }

            return $response;
        } catch (Exception $e) {
            Log::error('Update failed', ['error' => $e->getMessage(), 'trace' => $e->getTraceAsString()]);

            // Disable maintenance mode on error
            if (config('update.enable_maintenance')) {
                Artisan::call('up');
            }

            return response()->json([
                'success' => false,
                'message' => 'Update failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update version in .env file
     */
    protected function updateEnvVersion($version)
    {
        $envPath = base_path('.env');
        if (File::exists($envPath)) {
            $env = File::get($envPath);
            $env = preg_replace('/^APP_VERSION=.*/m', 'APP_VERSION=' . $version, $env);
            File::put($envPath, $env);
        }
    }

    /**
     * Run "composer dump-autoload -o" safely after updates.
     */
    protected function runComposerDumpAutoload(): void
    {
        Log::info('Starting composer dump-autoload optimization...');

        try {
            // Detect PHP path for XAMPP
            $phpPath = 'C:\\xampp\\php\\php.exe';
            if (!file_exists($phpPath)) {
                $phpPath = 'php'; // Fallback to global php
                Log::info('Using global PHP binary', ['php_path' => 'php']);
            } else {
                Log::info('Using XAMPP PHP binary', ['php_path' => $phpPath]);
            }

            // Method 1: Use Composer's ClassLoader directly (most reliable)
            Log::info('Attempting direct Composer ClassLoader optimization...');
            try {
                $composerAutoload = base_path('vendor/autoload.php');
                if (file_exists($composerAutoload)) {
                    require_once $composerAutoload;

                    // Run composer dump-autoload using exec
                    $composerCommand = sprintf(
                        'cd /d "%s" && "%s" -r "require \'%s\'; $loader = require \'%s\'; $gen = new \Composer\Autoload\AutoloadGenerator(new \Composer\IO\NullIO()); echo \'Autoload optimized\'; exit(0);" 2>&1',
                        base_path(),
                        $phpPath,
                        base_path('vendor/composer/composer/src/Composer/Autoload/AutoloadGenerator.php'),
                        $composerAutoload
                    );

                    Log::info('Attempting simplified composer via exec...');
                    $output1 = shell_exec(sprintf('cd /d "%s" && composer dump-autoload -o 2>&1', base_path()));

                    if ($output1 && !str_contains($output1, 'not recognized') && !str_contains($output1, 'Could not open')) {
                        Log::info('Composer dump-autoload completed successfully', [
                            'output' => $output1,
                            'method' => 'direct_composer'
                        ]);
                        return;
                    }

                    Log::info('Direct composer failed, trying with XAMPP PHP...', ['output' => $output1]);
                }
            } catch (\Throwable $e) {
                Log::info('Direct ClassLoader method failed', ['error' => $e->getMessage()]);
            }

            // Method 2: Try composer.phar if it exists
            $composerPhar = base_path('composer.phar');
            if (file_exists($composerPhar)) {
                Log::info('Trying composer.phar...');
                $command2 = sprintf('cd /d "%s" && "%s" "%s" dump-autoload -o 2>&1', base_path(), $phpPath, $composerPhar);
                $output2 = shell_exec($command2);

                if ($output2 && str_contains($output2, 'Generated optimized autoload')) {
                    Log::info('Composer dump-autoload completed successfully', [
                        'output' => $output2,
                        'method' => 'composer_phar'
                    ]);
                    return;
                }

                Log::info('Composer.phar failed or not found', ['output' => $output2]);
            }

            // Method 3: Try global composer with cd command
            Log::info('Trying global composer with full path...');
            $command3 = sprintf('cd /d "%s" && composer dump-autoload -o 2>&1', base_path());
            $output3 = shell_exec($command3);

            if ($output3 && str_contains($output3, 'Generated optimized autoload')) {
                Log::info('Composer dump-autoload completed successfully', [
                    'output' => $output3,
                    'method' => 'global_composer'
                ]);
                return;
            }

            Log::info('Global composer failed', ['output' => $output3]);

            // Method 4: Fallback to artisan optimize (regenerates cached files)
            Log::info('Using artisan optimize:clear as fallback...');
            Artisan::call('optimize:clear');
            $artisanOutput = Artisan::output();

            Log::info('Artisan optimize:clear completed', [
                'output' => $artisanOutput,
                'method' => 'artisan_optimize'
            ]);

            // Method 5: Direct file regeneration as last resort
            Log::info('Regenerating autoload files manually...');
            $regenerateCmd = sprintf('cd /d "%s" && "%s" artisan optimize 2>&1', base_path(), $phpPath);
            $regenerateOutput = shell_exec($regenerateCmd);

            Log::info('Manual optimization completed', [
                'output' => $regenerateOutput,
                'method' => 'manual_optimize'
            ]);
        } catch (\Throwable $e) {
            Log::error('Composer dump-autoload threw exception', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
        }
    }

    // ...rest of the controller...
}
