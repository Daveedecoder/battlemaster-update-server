<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Currency;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CurrencyController extends Controller
{
    /**
     * Display a listing of currencies with exchange rates
     */
    public function index()
    {
        $currencies = Currency::orderBy('code')->get();
        $admin = auth('admin')->user();
        $adminCurrency = $admin->currency ?? Currency::where('code', 'USD')->first();

        // Fetch live rates from FreeCurrencyAPI (cached internally for 1 hour)
        $liveRates = [];
        $liveFetchedAt = null;
        try {
            $service = app(\App\Services\CurrencyApiService::class);
            $targetCodes = $currencies->pluck('code')->toArray();
            $baseCode = $adminCurrency?->code ?? 'USD';
            $liveRates = $service->getLatestRates($baseCode, $targetCodes) ?? [];
            if (!empty($liveRates)) {
                $liveFetchedAt = now();
            }
        } catch (\Throwable $e) {
            // If live fetch fails, we just fall back to stored exchange_rate values
        }

        return view('admin.currencies.index', compact('currencies', 'adminCurrency', 'liveRates', 'liveFetchedAt'));
    }

    /**
     * Update exchange rates for currencies
     */
    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'currencies' => 'required|array',
            'currencies.*.id' => 'required|exists:currencies,id',
            'currencies.*.exchange_rate' => 'required|numeric|min:0.0001',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        try {
            foreach ($request->currencies as $currencyData) {
                Currency::where('id', $currencyData['id'])
                    ->update(['exchange_rate' => $currencyData['exchange_rate']]);
            }

            return redirect()->route('admin.currencies.index')
                ->with('success', 'Exchange rates updated successfully!');
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to update exchange rates. Please try again.')
                ->withInput();
        }
    }

    /**
     * Convert amount from one currency to another
     */
    public static function convertCurrency($amount, $fromCurrency, $toCurrency)
    {
        if ($fromCurrency->code === $toCurrency->code) {
            return $amount;
        }

        // Try live rates first via FreeCurrencyAPI (cached internally)
        try {
            $service = app(\App\Services\CurrencyApiService::class);
            $rates = $service->getLatestRates($fromCurrency->code, [$toCurrency->code]);
            if ($rates && isset($rates[$toCurrency->code])) {
                return round($amount * $rates[$toCurrency->code], 2);
            }
        } catch (\Throwable $e) {
            // Fallback silently to stored rates
        }

        // Find the base currency (the one with exchange_rate = 1.0000)
        // This ensures consistent conversions regardless of admin preferences
        $baseCurrency = Currency::where('exchange_rate', 1.0000)->first();
        if (!$baseCurrency) {
            // Fallback to USD if no base currency found with rate 1.0
            $baseCurrency = Currency::where('code', 'USD')->first();
            if (!$baseCurrency) {
                // Last resort: use USD as base
                $baseCurrency = Currency::where('code', 'USD')->first();
            }
        }

        // Convert to base currency first (if not already in base currency)
        if ($fromCurrency->id !== $baseCurrency->id) {
            // Convert from source currency to base currency
            // If fromCurrency has rate 1500 (meaning 1 base unit = 1500 of this currency),
            // divide the amount by the rate to get base currency amount
            $amount = $amount / $fromCurrency->exchange_rate;
        }

        // Convert from base currency to target currency (if not already base currency)
        if ($toCurrency->id !== $baseCurrency->id) {
            // Convert from base currency to target currency
            // If toCurrency has rate 1500 (meaning 1 base unit = 1500 of this currency),
            // multiply by the rate to get the target currency amount
            $amount = $amount * $toCurrency->exchange_rate;
        }

        return round($amount, 2);
    }

    /**
     * Get formatted amount in user's preferred currency
     */
    public static function formatAmountForUser($amount, $user = null, $baseCurrency = null)
    {
        if (!$user || !$user->currency) {
            $currency = Currency::where('code', 'NGN')->first();
        } else {
            $currency = $user->currency;
        }

        // If no base currency specified, determine it from the exchange rates
        // (the base currency has exchange_rate = 1.0)
        if (!$baseCurrency) {
            $baseCurrencyModel = Currency::where('exchange_rate', 1.0000)->first();
            if (!$baseCurrencyModel) {
                // Fallback to USD if no base currency found
                $baseCurrencyModel = Currency::where('code', 'USD')->first();
            }
        } else {
            $baseCurrencyModel = is_string($baseCurrency) ? Currency::where('code', $baseCurrency)->first() : $baseCurrency;
        }

        // Convert from base currency to user's currency
        $convertedAmount = self::convertCurrency($amount, $baseCurrencyModel, $currency);

        return $currency->formatAmount($convertedAmount);
    }
}
