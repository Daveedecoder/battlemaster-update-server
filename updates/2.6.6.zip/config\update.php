<?php

return [
    'enabled' => env('UPDATE_ENABLED', true),

    // GitHub-hosted update server (works locally and on production)
    'api_url' => env('UPDATE_API_URL', 'https://raw.githubusercontent.com/Daveedecoder/battlemaster-update-server/main'),

    // Current version from .env
    'current_version' => env('APP_VERSION', '1.0.0'),

    // This token must match your .env AUTH_TOKEN
    'auth_token' => env('UPDATE_AUTH_TOKEN', '2002300808302007'),

    'check_endpoint' => '/version.json',
    'download_endpoint' => '/updates/{version}.zip',

    // Local paths
    'temp_path' => storage_path('app/updates'),
    'backup_path' => storage_path('backups'),

    'backup_enabled' => true,
    'verify_checksum' => true,
    'timeout' => 600, // 10 minutes for large downloads
];