@extends('layouts.user')

@section('title', 'Ticket #' . $ticket->ticket_number)

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- Back Button -->
    <a href="{{ route('user.support.index') }}" class="inline-flex items-center text-blue-600 hover:text-blue-800 dark:text-blue-400 mb-6">
        <i class="fas fa-arrow-left mr-2"></i> Back to Tickets
    </a>

    @if(session('success'))
        <div class="bg-green-50 dark:bg-green-900/20 border-l-4 border-green-500 p-4 rounded mb-6">
            <p class="text-green-800 dark:text-green-300">{{ session('success') }}</p>
        </div>
    @endif

    {{-- Challenge Dispute Banner --}}
    @if($ticket->category === 'dispute')
        @php
            $disputeEscrow = \ChallengeAddon\Models\ChallengeEscrow::where('support_ticket_id', $ticket->id)->with('challenge')->first();
        @endphp
        @if($disputeEscrow && $disputeEscrow->challenge)
            <div class="bg-orange-50 dark:bg-orange-900/20 border-l-4 border-orange-500 p-5 rounded-lg mb-6">
                <div class="flex items-start">
                    <i class="fas fa-gavel text-orange-600 dark:text-orange-400 mt-1 mr-3 text-xl"></i>
                    <div class="flex-1">
                        <h3 class="font-bold text-orange-900 dark:text-orange-100 text-lg mb-2">
                            ⚖️ Challenge Dispute Resolution
                        </h3>
                        <p class="text-sm text-orange-800 dark:text-orange-200 mb-3">
                            This ticket is for resolving a dispute in <strong>{{ $disputeEscrow->challenge->title }}</strong> ({{ $disputeEscrow->challenge->challenge_number }}).
                            Both teams can submit evidence and communicate here.
                        </p>
                        <div class="bg-blue-50 dark:bg-blue-900/30 border border-blue-300 dark:border-blue-700 rounded-lg p-3 mb-3">
                            <div class="flex items-start">
                                <i class="fas fa-shield-alt text-blue-600 dark:text-blue-400 mt-0.5 mr-2"></i>
                                <div class="flex-1">
                                    <p class="text-xs font-semibold text-blue-900 dark:text-blue-200 mb-1">🔒 Privacy Protection Enabled</p>
                                    <p class="text-xs text-blue-800 dark:text-blue-300">
                                        Your team's uploaded files are only visible to your team and the escrow team. 
                                        The opposing team cannot see your evidence to prevent fraudulent copying. 
                                        Admins can view all submissions from both teams.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <a href="{{ route('challenges.user.show', $disputeEscrow->challenge) }}" 
                           class="inline-flex items-center text-orange-700 dark:text-orange-300 hover:text-orange-900 dark:hover:text-orange-100 font-semibold text-sm">
                            <i class="fas fa-trophy mr-2"></i>View Challenge Details
                            <i class="fas fa-arrow-right ml-2"></i>
                        </a>
                    </div>
                </div>
            </div>
        @endif
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Main Content -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Ticket Header -->
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <div class="flex items-start justify-between mb-4">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900 dark:text-white mb-2">{{ $ticket->subject }}</h1>
                        <div class="flex items-center space-x-3">
                            <span class="px-3 py-1 rounded-full text-xs font-semibold {{ $ticket->status_badge }}">
                                {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
                            </span>
                            <span class="px-3 py-1 rounded-full text-xs font-semibold {{ $ticket->priority_badge }}">
                                {{ ucfirst($ticket->priority) }}
                            </span>
                            <span class="text-sm text-gray-500 dark:text-gray-400">
                                {{ $ticket->category ? ucfirst(str_replace('_', ' ', $ticket->category)) : 'General' }}
                            </span>
                        </div>
                    </div>
                    @if($ticket->isOpen())
                        <form method="POST" action="{{ route('user.support.close', $ticket) }}" onsubmit="return confirm('Are you sure you want to close this ticket?')">
                            @csrf
                            <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition text-sm">
                                <i class="fas fa-times-circle mr-2"></i>Close Ticket
                            </button>
                        </form>
                    @endif
                </div>
                
                <div class="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                    <p class="text-gray-700 dark:text-gray-300 whitespace-pre-line">{{ $ticket->message }}</p>
                    
                    @if($ticket->attachment_path)
                        @php
                            // Check if user can view this attachment
                            $canViewAttachment = true;
                            if($ticket->category === 'dispute' && isset($userTeam) && $escrow) {
                                // Check if ticket creator is from user's team
                                $creatorParticipant = $escrow->challenge->participants()
                                    ->where('user_id', $ticket->user_id)
                                    ->first();
                                if ($creatorParticipant && $creatorParticipant->team !== $userTeam) {
                                    $canViewAttachment = false;
                                }
                            }
                        @endphp
                        
                        @if($canViewAttachment)
                            <div class="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                                <a href="{{ asset('storage/' . $ticket->attachment_path) }}" target="_blank" 
                                   class="inline-flex items-center text-blue-600 dark:text-blue-400 hover:underline">
                                    <i class="fas fa-paperclip mr-2"></i>
                                    <span>View Attachment</span>
                                    <i class="fas fa-external-link-alt ml-2 text-xs"></i>
                                </a>
                            </div>
                        @else
                            <div class="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                                <div class="inline-flex items-center text-gray-500 dark:text-gray-400">
                                    <i class="fas fa-lock mr-2"></i>
                                    <span class="text-sm italic">Attachment hidden (opposing team's evidence)</span>
                                </div>
                            </div>
                        @endif
                    @endif
                </div>
                
                <div class="mt-4 flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
                    <span><i class="fas fa-calendar mr-1"></i>Created {{ $ticket->created_at->diffForHumans() }}</span>
                    <span><i class="fas fa-clock mr-1"></i>{{ $ticket->created_at->format('M d, Y h:i A') }}</span>
                </div>
            </div>

            <!-- Replies -->
            @if($ticket->replies->count() > 0)
                <div class="space-y-4">
                    <h2 class="text-xl font-bold text-gray-900 dark:text-white">Conversation</h2>
                    
                    @foreach($ticket->replies as $reply)
                        @if(!$reply->is_internal)
                            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 {{ $reply->isFromAdmin() ? 'border-l-4 border-blue-500' : '' }}">
                                <div class="flex items-start space-x-4">
                                    <div class="w-10 h-10 rounded-full {{ $reply->isFromAdmin() ? 'bg-blue-500' : 'bg-gray-500' }} flex items-center justify-center text-white font-bold">
                                        @if($reply->isFromAdmin())
                                            <i class="fas fa-user-shield"></i>
                                        @else
                                            {{ substr($reply->author->username, 0, 1) }}
                                        @endif
                                    </div>
                                    <div class="flex-1">
                                        <div class="flex items-center space-x-2 mb-2">
                                            <span class="font-semibold text-gray-900 dark:text-white">
                                                {{ $reply->author->username }}
                                            </span>
                                            @if($reply->isFromAdmin())
                                                <span class="px-2 py-1 bg-blue-500/20 text-blue-600 dark:text-blue-400 text-xs rounded-full font-semibold">
                                                    Support Team
                                                </span>
                                            @endif
                                            <span class="text-sm text-gray-500 dark:text-gray-400">
                                                {{ $reply->created_at->diffForHumans() }}
                                            </span>
                                        </div>
                                        <p class="text-gray-700 dark:text-gray-300 whitespace-pre-line">{{ $reply->message }}</p>
                                        
                                        @if($reply->attachment_path)
                                            @php
                                                // Check if user can view this reply's attachment
                                                $canViewReplyAttachment = true;
                                                if($ticket->category === 'dispute' && isset($userTeam) && $escrow && !$reply->isFromAdmin()) {
                                                    // Check if reply author is from user's team
                                                    $replyAuthorParticipant = $escrow->challenge->participants()
                                                        ->where('user_id', $reply->author_id)
                                                        ->first();
                                                    if ($replyAuthorParticipant && $replyAuthorParticipant->team !== $userTeam) {
                                                        $canViewReplyAttachment = false;
                                                    }
                                                }
                                            @endphp
                                            
                                            @if($canViewReplyAttachment)
                                                <div class="mt-3">
                                                    <a href="{{ asset('storage/' . $reply->attachment_path) }}" target="_blank" 
                                                       class="inline-flex items-center text-blue-600 dark:text-blue-400 hover:underline text-sm">
                                                        <i class="fas fa-paperclip mr-2"></i>
                                                        <span>View Attachment</span>
                                                        <i class="fas fa-external-link-alt ml-2 text-xs"></i>
                                                    </a>
                                                </div>
                                            @else
                                                <div class="mt-3">
                                                    <div class="inline-flex items-center text-gray-500 dark:text-gray-400">
                                                        <i class="fas fa-lock mr-2"></i>
                                                        <span class="text-sm italic">Attachment hidden (opposing team's evidence)</span>
                                                    </div>
                                                </div>
                                            @endif
                                        @endif
                                    </div>
                                </div>
                            </div>
                        @endif
                    @endforeach
                </div>
            @endif

            <!-- Reply Form -->
            @if($ticket->isOpen())
                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-4">Add Reply</h2>
                    
                    <form method="POST" action="{{ route('user.support.reply', $ticket) }}" enctype="multipart/form-data">
                        @csrf
                        <textarea name="message" rows="6" required
                                  class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white mb-4"
                                  placeholder="Type your reply here...">{{ old('message') }}</textarea>
                        @error('message')
                            <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                        @enderror
                        
                        <!-- Attachment Upload -->
                        <div class="mb-4">
                            <label for="reply_attachment" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                Attach File <span class="text-gray-500">(Optional)</span>
                            </label>
                            <input type="file" id="reply_attachment" name="attachment" accept=".jpg,.jpeg,.png,.pdf,.doc,.docx,.txt"
                                   class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 dark:file:bg-gray-600 dark:file:text-gray-200">
                            <p class="text-sm text-gray-500 dark:text-gray-400 mt-2">
                                <i class="fas fa-paperclip mr-1"></i>
                                Max 5MB - JPG, PNG, PDF, DOC, DOCX, TXT
                            </p>
                        </div>
                        
                        <div class="flex justify-end mt-4">
                            <button type="submit" class="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-2 rounded-lg transition shadow-lg">
                                <i class="fas fa-paper-plane mr-2"></i>Send Reply
                            </button>
                        </div>
                    </form>
                </div>
            @else
                <div class="bg-gray-50 dark:bg-gray-700 rounded-lg p-6 text-center">
                    <i class="fas fa-lock text-4xl text-gray-400 mb-3"></i>
                    <p class="text-gray-600 dark:text-gray-400">This ticket is closed and cannot receive new replies.</p>
                </div>
            @endif
        </div>

        <!-- Sidebar -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Ticket Info -->
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <h3 class="text-lg font-bold text-gray-900 dark:text-white mb-4">Ticket Information</h3>
                <div class="space-y-3">
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400">Ticket Number</p>
                        <p class="font-semibold text-gray-900 dark:text-white">{{ $ticket->ticket_number }}</p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400">Status</p>
                        <span class="px-3 py-1 rounded-full text-xs font-semibold {{ $ticket->status_badge }}">
                            {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
                        </span>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400">Priority</p>
                        <span class="px-3 py-1 rounded-full text-xs font-semibold {{ $ticket->priority_badge }}">
                            {{ ucfirst($ticket->priority) }}
                        </span>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400">Category</p>
                        <p class="font-semibold text-gray-900 dark:text-white">
                            {{ $ticket->category ? ucfirst(str_replace('_', ' ', $ticket->category)) : 'General' }}
                        </p>
                    </div>
                    @if($ticket->assignedAdmin)
                        <div>
                            <p class="text-sm text-gray-500 dark:text-gray-400">Assigned To</p>
                            <p class="font-semibold text-gray-900 dark:text-white">{{ $ticket->assignedAdmin->name }}</p>
                        </div>
                    @endif
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400">Created</p>
                        <p class="font-semibold text-gray-900 dark:text-white">{{ $ticket->created_at->format('M d, Y h:i A') }}</p>
                    </div>
                    @if($ticket->closed_at)
                        <div>
                            <p class="text-sm text-gray-500 dark:text-gray-400">Closed</p>
                            <p class="font-semibold text-gray-900 dark:text-white">{{ $ticket->closed_at->format('M d, Y h:i A') }}</p>
                        </div>
                    @endif
                </div>
            </div>

            <!-- Help -->
            <div class="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 border border-blue-200 dark:border-blue-800">
                <h3 class="text-lg font-bold text-blue-900 dark:text-blue-300 mb-3">Need Faster Help?</h3>
                <p class="text-sm text-blue-800 dark:text-blue-400 mb-4">
                    For urgent issues, you can also contact us through:
                </p>
                <ul class="space-y-2 text-sm text-blue-800 dark:text-blue-400">
                    <li><i class="fas fa-envelope mr-2"></i>Email: support@example.com</li>
                    <li><i class="fas fa-phone mr-2"></i>Phone: +1 (555) 123-4567</li>
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection
