@extends('layouts.admin')

@section('title', 'Ticket #' . $ticket->ticket_number)

@section('content')
<div class="p-6">
    <!-- Back Button -->
    <a href="{{ route('admin.support.index') }}" class="inline-flex items-center text-slate-400 hover:text-white transition mb-6">
        <i class="fas fa-arrow-left mr-2"></i> Back to Tickets
    </a>

    @if(session('success'))
        <div class="bg-green-500/20 border border-green-500/30 text-green-400 px-6 py-4 rounded-lg mb-6">
            {{ session('success') }}
        </div>
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Main Content -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Ticket Header -->
            <div class="bg-slate-800 rounded-xl p-6 border border-slate-700">
                <div class="flex items-start justify-between mb-4">
                    <div class="flex-1">
                        <h1 class="text-2xl font-bold text-white mb-3">{{ $ticket->subject }}</h1>
                        <div class="flex items-center space-x-3 mb-4">
                            <span class="px-3 py-1 rounded-full text-xs font-semibold {{ $ticket->status_badge }}">
                                {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
                            </span>
                            <span class="px-3 py-1 rounded-full text-xs font-semibold {{ $ticket->priority_badge }}">
                                {{ ucfirst($ticket->priority) }}
                            </span>
                            <span class="text-sm text-slate-400">
                                {{ $ticket->category ? ucfirst(str_replace('_', ' ', $ticket->category)) : 'General' }}
                            </span>
                        </div>
                    </div>
                </div>
                
                <div class="bg-slate-700 rounded-lg p-4 mb-4">
                    <div class="flex items-center space-x-3 mb-3">
                        <div class="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                            {{ substr($ticket->user->username, 0, 1) }}
                        </div>
                        <div>
                            <p class="font-semibold text-white">{{ $ticket->user->username }}</p>
                            <p class="text-sm text-slate-400">{{ $ticket->created_at->format('M d, Y h:i A') }}</p>
                        </div>
                    </div>
                    <p class="text-slate-300 whitespace-pre-line">{{ $ticket->message }}</p>
                    
                    @if($ticket->attachment_path)
                        <div class="mt-4 pt-4 border-t border-slate-600">
                            <a href="{{ asset('storage/' . $ticket->attachment_path) }}" target="_blank" 
                               class="inline-flex items-center text-blue-400 hover:text-blue-300 transition">
                                <i class="fas fa-paperclip mr-2"></i>
                                <span>View Attachment</span>
                                <i class="fas fa-external-link-alt ml-2 text-xs"></i>
                            </a>
                        </div>
                    @endif
                </div>
            </div>

            <!-- Conversation -->
            @if($ticket->replies->count() > 0)
                <div class="space-y-4">
                    <h2 class="text-xl font-bold text-white">Conversation History</h2>
                    
                    @foreach($ticket->replies as $reply)
                        <div class="bg-slate-800 rounded-xl p-6 border {{ $reply->isFromAdmin() ? 'border-blue-500/50 bg-blue-500/5' : 'border-slate-700' }}">
                            <div class="flex items-start space-x-4">
                                <div class="w-10 h-10 rounded-full {{ $reply->isFromAdmin() ? 'bg-blue-500' : 'bg-gray-500' }} flex items-center justify-center text-white font-bold">
                                    @if($reply->isFromAdmin())
                                        <i class="fas fa-user-shield"></i>
                                    @else
                                        {{ substr($reply->author->username, 0, 1) }}
                                    @endif
                                </div>
                                <div class="flex-1">
                                    <div class="flex items-center space-x-3 mb-2">
                                        <span class="font-semibold text-white">{{ $reply->author->username }}</span>
                                        @if($reply->isFromAdmin())
                                            <span class="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded-full font-semibold">
                                                Admin
                                            </span>
                                        @endif
                                        @if($reply->is_internal)
                                            <span class="px-2 py-1 bg-orange-500/20 text-orange-400 text-xs rounded-full font-semibold">
                                                Internal Note
                                            </span>
                                        @endif
                                        <span class="text-sm text-slate-400">{{ $reply->created_at->diffForHumans() }}</span>
                                    </div>
                                    <p class="text-slate-300 whitespace-pre-line">{{ $reply->message }}</p>
                                    
                                    @if($reply->attachment_path)
                                        <div class="mt-3 pt-3 border-t border-slate-600">
                                            <a href="{{ asset('storage/' . $reply->attachment_path) }}" target="_blank" 
                                               class="inline-flex items-center text-blue-400 hover:text-blue-300 transition text-sm">
                                                <i class="fas fa-paperclip mr-2"></i>
                                                <span>View Attachment</span>
                                                <i class="fas fa-external-link-alt ml-2 text-xs"></i>
                                            </a>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endif

            <!-- Reply Form -->
            @if($ticket->isOpen())
                <div class="bg-slate-800 rounded-xl p-6 border border-slate-700">
                    <h2 class="text-xl font-bold text-white mb-4">Add Reply</h2>
                    
                    <form method="POST" action="{{ route('admin.support.reply', $ticket) }}" enctype="multipart/form-data">
                        @csrf
                        <textarea name="message" rows="6" required
                                  class="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 mb-4"
                                  placeholder="Type your reply...">{{ old('message') }}</textarea>
                        @error('message')
                            <p class="text-red-400 text-sm mt-1">{{ $message }}</p>
                        @enderror
                        
                        <!-- Attachment Upload -->
                        <div class="mb-4">
                            <label for="admin_attachment" class="block text-sm font-medium text-slate-300 mb-2">
                                Attach File <span class="text-slate-500">(Optional)</span>
                            </label>
                            <input type="file" id="admin_attachment" name="attachment" accept=".jpg,.jpeg,.png,.pdf,.doc,.docx,.txt"
                                   class="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-500/20 file:text-blue-400 hover:file:bg-blue-500/30">
                            <p class="text-sm text-slate-400 mt-2">
                                <i class="fas fa-paperclip mr-1"></i>
                                Max 5MB - JPG, PNG, PDF, DOC, DOCX, TXT
                            </p>
                        </div>
                        
                        <div class="flex items-center justify-between mt-4">
                            <label class="flex items-center text-slate-300">
                                <input type="checkbox" name="is_internal" value="1" class="mr-2 rounded bg-slate-700 border-slate-600 text-blue-500 focus:ring-blue-500">
                                <span class="text-sm">Internal note (not visible to user)</span>
                            </label>
                            
                            <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-lg transition">
                                <i class="fas fa-paper-plane mr-2"></i>Send Reply
                            </button>
                        </div>
                    </form>
                </div>
            @endif
        </div>

        <!-- Sidebar -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Quick Actions -->
            <div class="bg-slate-800 rounded-xl p-6 border border-slate-700">
                <h3 class="text-lg font-bold text-white mb-4">Quick Actions</h3>
                
                <!-- Update Status -->
                <form method="POST" action="{{ route('admin.support.updateStatus', $ticket) }}" class="mb-4">
                    @csrf
                    <label class="block text-sm font-medium text-slate-300 mb-2">Status</label>
                    <div class="flex space-x-2">
                        <select name="status" class="flex-1 px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white text-sm focus:ring-2 focus:ring-blue-500">
                            <option value="open" {{ $ticket->status == 'open' ? 'selected' : '' }}>Open</option>
                            <option value="in_progress" {{ $ticket->status == 'in_progress' ? 'selected' : '' }}>In Progress</option>
                            <option value="waiting_user" {{ $ticket->status == 'waiting_user' ? 'selected' : '' }}>Waiting User</option>
                            <option value="resolved" {{ $ticket->status == 'resolved' ? 'selected' : '' }}>Resolved</option>
                            <option value="closed" {{ $ticket->status == 'closed' ? 'selected' : '' }}>Closed</option>
                        </select>
                        <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm transition">
                            Update
                        </button>
                    </div>
                </form>

                <!-- Update Priority -->
                <form method="POST" action="{{ route('admin.support.updatePriority', $ticket) }}" class="mb-4">
                    @csrf
                    <label class="block text-sm font-medium text-slate-300 mb-2">Priority</label>
                    <div class="flex space-x-2">
                        <select name="priority" class="flex-1 px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white text-sm focus:ring-2 focus:ring-blue-500">
                            <option value="low" {{ $ticket->priority == 'low' ? 'selected' : '' }}>Low</option>
                            <option value="medium" {{ $ticket->priority == 'medium' ? 'selected' : '' }}>Medium</option>
                            <option value="high" {{ $ticket->priority == 'high' ? 'selected' : '' }}>High</option>
                            <option value="urgent" {{ $ticket->priority == 'urgent' ? 'selected' : '' }}>Urgent</option>
                        </select>
                        <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm transition">
                            Update
                        </button>
                    </div>
                </form>

                <!-- Assign To -->
                <form method="POST" action="{{ route('admin.support.assign', $ticket) }}">
                    @csrf
                    <label class="block text-sm font-medium text-slate-300 mb-2">Assign To</label>
                    <div class="flex space-x-2">
                        <select name="assigned_to" class="flex-1 px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white text-sm focus:ring-2 focus:ring-blue-500">
                            <option value="">Unassigned</option>
                            @foreach($admins as $admin)
                                <option value="{{ $admin->id }}" {{ $ticket->assigned_to == $admin->id ? 'selected' : '' }}>
                                    {{ $admin->name }}
                                </option>
                            @endforeach
                        </select>
                        <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm transition">
                            Assign
                        </button>
                    </div>
                </form>
            </div>

            <!-- Ticket Details -->
            <div class="bg-slate-800 rounded-xl p-6 border border-slate-700">
                <h3 class="text-lg font-bold text-white mb-4">Ticket Details</h3>
                <div class="space-y-3">
                    <div>
                        <p class="text-sm text-slate-400">Ticket Number</p>
                        <p class="font-mono text-white">{{ $ticket->ticket_number }}</p>
                    </div>
                    <div>
                        <p class="text-sm text-slate-400">User</p>
                        <p class="font-semibold text-white">{{ $ticket->user->name }}</p>
                        <p class="text-sm text-slate-400">{{ $ticket->user->email }}</p>
                    </div>
                    <div>
                        <p class="text-sm text-slate-400">Category</p>
                        <p class="font-semibold text-white">
                            {{ $ticket->category ? ucfirst(str_replace('_', ' ', $ticket->category)) : 'General' }}
                        </p>
                    </div>
                    <div>
                        <p class="text-sm text-slate-400">Created</p>
                        <p class="font-semibold text-white">{{ $ticket->created_at->format('M d, Y h:i A') }}</p>
                        <p class="text-xs text-slate-500">{{ $ticket->created_at->diffForHumans() }}</p>
                    </div>
                    <div>
                        <p class="text-sm text-slate-400">Last Updated</p>
                        <p class="font-semibold text-white">{{ $ticket->updated_at->format('M d, Y h:i A') }}</p>
                        <p class="text-xs text-slate-500">{{ $ticket->updated_at->diffForHumans() }}</p>
                    </div>
                    @if($ticket->closed_at)
                        <div>
                            <p class="text-sm text-slate-400">Closed</p>
                            <p class="font-semibold text-white">{{ $ticket->closed_at->format('M d, Y h:i A') }}</p>
                        </div>
                    @endif
                    <div>
                        <p class="text-sm text-slate-400">Total Replies</p>
                        <p class="font-semibold text-white">{{ $ticket->replies->count() }}</p>
                    </div>
                </div>
            </div>

            <!-- User Info -->
            <div class="bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl p-6 border border-blue-500/30">
                <h3 class="text-lg font-bold text-white mb-4">User Information</h3>
                <div class="space-y-2 text-sm">
                    <p class="text-slate-300">
                        <i class="fas fa-envelope mr-2 text-blue-400"></i>
                        {{ $ticket->user->email }}
                    </p>
                    <p class="text-slate-300">
                        <i class="fas fa-calendar mr-2 text-blue-400"></i>
                        Member since {{ $ticket->user->created_at->format('M Y') }}
                    </p>
                    <p class="text-slate-300">
                        <i class="fas fa-ticket-alt mr-2 text-blue-400"></i>
                        {{ $ticket->user->supportTickets()->count() }} total tickets
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
