<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\PaymentMethod;
use App\Models\WalletTransaction;
use App\Models\Transaction;
use App\Models\User;
use Illuminate\Support\Facades\Http;
use App\Services\StripeService;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

class DepositController extends Controller
{
    public function showDepositForm()
    {
        // Get only active payment methods
        $paymentMethods = PaymentMethod::where('status', 'active')->get();

        // Build a unified deposit history merging WalletTransaction (new) and Transaction (legacy gateway logs)
        $userId = Auth::id();

        $walletTx = WalletTransaction::where('user_id', $userId)
            ->where('type', 'deposit')
            ->get()
            ->map(function ($tx) {
                return (object) [
                    'reference' => $tx->reference,
                    'amount' => $tx->amount,
                    'status' => $tx->status,
                    'description' => $tx->description ?: 'Wallet Deposit',
                    'currency' => $tx->currency,
                    'created_at' => $tx->created_at,
                ];
            });

        // Include legacy gateway Transaction records for visibility of older deposits
        $gatewayTx = Transaction::where('user_id', $userId)
            ->orderBy('created_at', 'desc')
            ->get()
            ->map(function ($tx) {
                $desc = $tx->description;
                if (!$desc && $tx->gateway) {
                    $desc = $tx->gateway . ' Deposit';
                }
                $currentUserCurrency = get_user_currency(Auth::user());
                return (object) [
                    'reference' => $tx->reference,
                    'amount' => $tx->amount,
                    'status' => $tx->status,
                    'description' => $desc ?: 'Deposit',
                    // Best-effort: legacy Transaction amount was captured in the user's currency at the time
                    // Tag with current user's currency for consistent display
                    'currency' => $currentUserCurrency?->code,
                    'created_at' => $tx->created_at,
                ];
            });

        $merged = $walletTx->concat($gatewayTx)
            ->sortByDesc('created_at')
            ->values();

        // Paginate the merged collection manually
        $perPage = 10;
        $currentPage = (int) (request()->get('page', 1));
        $slice = $merged->slice(($currentPage - 1) * $perPage, $perPage)->values();
        $transactions = new LengthAwarePaginator(
            $slice,
            $merged->count(),
            $perPage,
            $currentPage,
            ['path' => request()->url(), 'query' => request()->query()]
        );

        // Check which payment methods are active AND have their respective keys configured
        $hasPaystack = $paymentMethods->contains(function ($m) {
            return $m->name === 'Paystack'
                && !empty($m->paystack_public_key)
                && !empty($m->paystack_secret_key);
        });

        $hasFlutterwave = $paymentMethods->contains(function ($m) {
            return $m->name === 'Flutterwave'
                && !empty($m->flutterwave_public_key)
                && !empty($m->flutterwave_secret_key);
        });

        $hasStripe = $paymentMethods->contains(function ($m) {
            return $m->name === 'Stripe'
                && !empty($m->stripe_public_key)
                && !empty($m->stripe_secret_key);
        });

        return view('user.wallet.deposit', compact('paymentMethods', 'transactions', 'hasPaystack', 'hasFlutterwave', 'hasStripe'));
    }

    public function handleDeposit(Request $request)
    {
        $user = Auth::user();
        $minAmount = get_min_deposit_amount($user);

        $request->validate([
            'amount' => "required|numeric|min:{$minAmount}",
            'method' => 'required|string|in:paystack,flutterwave,stripe',
        ]);

        $amount = $request->amount;
        $method = $request->method;
        $user = Auth::user();

        // Get the specific active payment method for the selected provider
        $payment = PaymentMethod::where('status', 'active')
            ->where(function ($query) use ($method) {
                $query->where('name', $method)
                    ->orWhere(function ($q) use ($method) {
                        // Check if the method's keys exist and are not null
                        $q->whereNotNull($method . '_public_key')
                            ->whereNotNull($method . '_secret_key');
                    });
            })
            ->first();

        if (!$payment) {
            return redirect()->route('user.deposit')->with('error', 'Selected payment method is currently unavailable.');
        }

        session(['deposit_amount' => $amount, 'deposit_method' => $method]);

        switch ($method) {
            case 'paystack':
                $userCurrency = get_user_currency($user);
                $response = Http::withHeaders([
                    'Authorization' => "Bearer {$payment->paystack_secret_key}"
                ])->post('https://api.paystack.co/transaction/initialize', [
                    'email' => $user->email,
                    'amount' => $amount * 100,
                    'currency' => $userCurrency->code,
                    'callback_url' => route('user.deposit.callback'),
                ]);
                $data = $response->json();
                if (isset($data['status']) && $data['status'] && isset($data['data']['authorization_url'])) {
                    return redirect($data['data']['authorization_url']);
                } else {
                    $msg = $data['message'] ?? 'Paystack deposit initialization failed.';
                    return redirect()->route('user.deposit')->with('error', $msg);
                }

            case 'flutterwave':
                $userCurrency = get_user_currency($user);
                $txRef = 'FLW-' . uniqid() . '-' . time();

                // Create pending transaction record
                Transaction::create([
                    'user_id' => $user->id,
                    'reference' => $txRef,
                    'amount' => $amount,
                    'status' => 'pending',
                    'gateway' => 'Flutterwave',
                ]);

                // Store transaction reference and amount in session for verification
                session(['flutterwave_tx_ref' => $txRef, 'deposit_amount' => $amount, 'deposit_method' => 'flutterwave']);

                $response = Http::withHeaders([
                    'Authorization' => "Bearer {$payment->flutterwave_secret_key}"
                ])->post('https://api.flutterwave.com/v3/payments', [
                    'tx_ref' => $txRef,
                    'amount' => $amount,
                    'currency' => $userCurrency->code,
                    'redirect_url' => route('flutterwave.callback'),
                    'customer' => [
                        'email' => $user->email,
                        'name' => $user->name,
                    ],
                    'customizations' => [
                        'title' => 'Wallet Deposit',
                        'description' => 'Deposit into wallet',
                    ],
                ]);
                $data = $response->json();
                if (isset($data['status']) && $data['status'] && isset($data['data']['link'])) {
                    return redirect($data['data']['link']);
                } else {
                    $msg = $data['message'] ?? 'Flutterwave deposit initialization failed.';
                    return redirect()->route('user.deposit')->with('error', $msg);
                }

            case 'stripe':
                // Supported Stripe currencies (expand as needed)
                $supportedCurrencies = ['USD', 'EUR', 'GBP', 'GHS', 'KES', 'ZAR', 'AUD', 'CAD', 'SGD'];
                $userCurrency = get_user_currency($user);
                $currency = strtoupper($userCurrency->code);
                if (!in_array($currency, $supportedCurrencies)) {
                    return redirect()->route('user.deposit')->with('error', 'Stripe does not accept ' . $currency . '. Please use another payment method or change your currency to one of these: ' . implode(', ', $supportedCurrencies) . '.');
                }
                try {
                    $txRef = 'STR-' . uniqid() . '-' . time();

                    // Create pending transaction record (like Flutterwave)
                    Transaction::create([
                        'user_id' => $user->id,
                        'reference' => $txRef,
                        'amount' => $amount,
                        'status' => 'pending',
                        'gateway' => 'Stripe',
                    ]);

                    // Store transaction reference and amount in session for verification
                    session(['stripe_tx_ref' => $txRef, 'deposit_amount' => $amount, 'deposit_method' => 'stripe']);

                    $stripeService = new StripeService($payment->stripe_secret_key);
                    $sessionUrl = $stripeService->createDepositSession(
                        $amount,
                        $currency,
                        $user->email,
                        route('stripe.callback'),
                        route('user.deposit'),
                        $txRef  // Pass transaction reference to Stripe
                    );
                    return redirect($sessionUrl);
                } catch (\Exception $e) {
                    return redirect()->route('user.deposit')->with('error', 'Stripe error: ' . $e->getMessage());
                }
        }
    }

    public function callback(Request $request)
    {
        $user = Auth::user();
        $amount = session('deposit_amount');
        $method = session('deposit_method', 'unknown');

        // Stripe callback is now handled by StripeController
        if ($method === 'stripe') {
            return redirect()->route('user.deposit');
        }

        // For Paystack, verify the transaction
        if ($method === 'paystack') {
            $reference = $request->query('reference');

            if (!$reference) {
                session()->forget(['deposit_amount', 'deposit_method']);
                return redirect()->route('user.deposit')->with('error', 'Invalid payment reference.');
            }

            $payment = PaymentMethod::where('name', 'Paystack')->where('status', 'active')->first();

            if (!$payment || !$payment->paystack_secret_key) {
                session()->forget(['deposit_amount', 'deposit_method']);
                return redirect()->route('user.deposit')->with('error', 'Payment method not configured.');
            }

            try {
                $response = Http::withToken($payment->paystack_secret_key)
                    ->get("https://api.paystack.co/transaction/verify/{$reference}");

                $res = $response->json();

                if (!isset($res['status']) || !$res['status'] || $res['data']['status'] !== 'success') {
                    session()->forget(['deposit_amount', 'deposit_method']);
                    return redirect()->route('user.deposit')->with('error', 'Payment verification failed.');
                }

                // Update legacy Transaction entry to success if it exists
                if (!empty($reference)) {
                    Transaction::where('user_id', $user->id)
                        ->where('reference', $reference)
                        ->update([
                            'status' => 'success',
                            'description' => 'Paystack Wallet Deposit',
                        ]);
                }
            } catch (\Exception $e) {
                session()->forget(['deposit_amount', 'deposit_method']);
                return redirect()->route('user.deposit')->with('error', 'Payment verification failed.');
            }
        }

        if ($amount) {
            // Get user's currency
            $userCurrency = get_user_currency($user);

            // Store the ORIGINAL transaction amount FIRST (in user's currency)
            // Generate transaction reference/ID
            $transactionRef = null;
            if ($method === 'stripe') {
                $transactionRef = session('stripe_tx_ref');
            } elseif ($method === 'paystack') {
                $transactionRef = $request->query('reference');
            } elseif ($method === 'flutterwave') {
                $transactionRef = session('flutterwave_tx_ref');
            }

            // Store transaction with the ORIGINAL amount in user's currency
            WalletTransaction::create([
                'user_id' => $user->id,
                'type' => 'credit',  // Deposits are credits to the user's wallet
                'amount' => $amount,
                    'currency' => $userCurrency->code,
                'status' => 'success',
                'description' => ucfirst($method) . ' Wallet Deposit',
                'reference' => $transactionRef,
            ]);

            // Convert deposited amount to USD (base currency) for wallet storage ONLY
            $baseCurrency = \App\Models\Currency::where('code', 'USD')->first();
            $amountInUSD = convert_currency($amount, $userCurrency, $baseCurrency);

            // Wallet stores balance in USD (base currency)
            $wallet = \App\Models\Wallet::firstOrCreate(['user_id' => $user->id]);
            $wallet->increment('balance', $amountInUSD);

            session()->forget(['deposit_amount', 'deposit_method']);
        }

        return redirect()->route('user.deposit')->with('success', 'Deposit successful!');
    }
}
