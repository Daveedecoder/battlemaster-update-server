<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * Make winner_team nullable since it's not set during proof submission anymore.
     */
    public function up(): void
    {
        Schema::table('challenge_escrows', function (Blueprint $table) {
            $table->string('winner_team')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('challenge_escrows', function (Blueprint $table) {
            $table->string('winner_team')->change();
        });
    }
};
